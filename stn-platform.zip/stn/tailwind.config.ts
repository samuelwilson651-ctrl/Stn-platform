import type { Config } from "tailwindcss";

const config: Config = {
  content: [
    "./src/pages/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/components/**/*.{js,ts,jsx,tsx,mdx}",
    "./src/app/**/*.{js,ts,jsx,tsx,mdx}",
  ],
  darkMode: "class",
  theme: {
    extend: {
      colors: {
        navy: {
          DEFAULT: "#0f1e35",
          mid: "#1a2e4a",
          light: "#1e3a5f",
        },
        gold: {
          DEFAULT: "#c9a84c",
          light: "#e3c87a",
          dim: "rgba(201,168,76,0.15)",
        },
        cream: {
          DEFAULT: "#faf7f2",
          dark: "#f0ebe1",
        },
        earth: {
          DEFAULT: "#8b7355",
          light: "#a8956e",
        },
        muted: "#6b6256",
      },
      fontFamily: {
        display: ["var(--font-cinzel)", "Trajan Pro", "serif"],
        serif: ["var(--font-cormorant)", "Georgia", "serif"],
        body: ["var(--font-inter)", "system-ui", "sans-serif"],
      },
      fontSize: {
        "display-xl": ["clamp(3.5rem, 10vw, 8rem)", { lineHeight: "0.95" }],
        "display-lg": ["clamp(2.5rem, 6vw, 5rem)", { lineHeight: "1.05" }],
        "display-md": ["clamp(2rem, 4vw, 3rem)", { lineHeight: "1.2" }],
        "serif-xl": ["clamp(1.25rem, 2.5vw, 1.75rem)", { lineHeight: "1.65" }],
        "eyebrow": ["0.68rem", { letterSpacing: "0.22em" }],
        "label": ["0.72rem", { letterSpacing: "0.18em" }],
      },
      spacing: {
        "section": "7rem",
        "section-sm": "4rem",
      },
      borderRadius: {
        DEFAULT: "2px",
        md: "4px",
        lg: "8px",
      },
      boxShadow: {
        sm: "0 2px 12px rgba(15,30,53,0.06)",
        md: "0 6px 30px rgba(15,30,53,0.10)",
        lg: "0 16px 60px rgba(15,30,53,0.14)",
        "gold": "0 0 0 1.5px #c9a84c",
      },
      animation: {
        "fade-up": "fadeUp 0.7s ease forwards",
        "glow-pulse": "glowPulse 4s ease-in-out infinite",
      },
      keyframes: {
        fadeUp: {
          from: { opacity: "0", transform: "translateY(18px)" },
          to: { opacity: "1", transform: "translateY(0)" },
        },
        glowPulse: {
          "0%, 100%": { opacity: "0.5" },
          "50%": { opacity: "1" },
        },
      },
      backgroundImage: {
        "navy-gradient": "linear-gradient(135deg, #0f1e35 0%, #1a2e4a 100%)",
        "gold-gradient": "linear-gradient(135deg, #c9a84c 0%, #e3c87a 100%)",
        "cream-gradient": "linear-gradient(180deg, #faf7f2 0%, #f0ebe1 100%)",
      },
    },
  },
  plugins: [],
};

export default config;
