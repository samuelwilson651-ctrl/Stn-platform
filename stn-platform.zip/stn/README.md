# Silence the Noise™ — Complete Platform Repository

**Dr. Samuel E. Wilson, MD**  
Physician · Author · Educator · Speaker · Inventor

> *"Many people do not simply need more information. They need less noise."*

---

## What This Is

A complete, production-ready Next.js 14 platform for **samuelewilson.org** — the digital home of the Silence the Noise™ framework.

This is not a blog template. This is a full physician-led faith-and-wellness platform architecture supporting:

- **Content publishing** — articles, devotionals, podcast, video series
- **Membership monetization** — Stripe subscriptions with Clerk auth
- **Course sales** — one-time purchases with access control
- **Email marketing** — newsletter capture, automated sequences via Resend
- **Community** — member-gated discussion (ready to integrate Circle/Mighty Networks)
- **Speaking bookings** — inquiry capture with automated email confirmation
- **SEO** — structured data, sitemap, Open Graph, per-page metadata
- **Framework architecture** — every piece of content tagged by pillar + category

---

## Tech Stack

| Layer | Technology |
|---|---|
| Framework | Next.js 14 (App Router) |
| Language | TypeScript (strict) |
| Styling | Tailwind CSS + CSS Custom Properties |
| CMS | Sanity v3 |
| Auth | Clerk |
| Payments | Stripe |
| Email | Resend |
| Analytics | Vercel Analytics + GA4 |
| Deployment | Vercel |
| CI/CD | GitHub Actions |

---

## Revenue Streams (Configured)

| Product | Price | Type |
|---|---|---|
| Monthly Membership | $17/mo | Subscription |
| Annual Membership | $132/yr | Subscription (save 35%) |
| Silence the Noise™ Course | $297 | One-time |
| Coaching Session | $197 | One-time |
| Physician Consultation | $497 | One-time |
| Speaking & Workshops | Custom | Inquiry → Manual |

---

## Quick Start

### 1. Clone & Install

```bash
git clone https://github.com/samuelewilson/silence-the-noise.git
cd silence-the-noise
npm install
```

### 2. Environment Variables

```bash
cp .env.example .env.local
```

Then fill in each value. See the section below for where to get each key.

### 3. Set Up Stripe Products

```bash
npm run stripe:setup
```

Copy the printed price IDs into `.env.local`.

### 4. Set Up Stripe Webhook (Local Dev)

```bash
# Install Stripe CLI: https://stripe.com/docs/stripe-cli
stripe login
stripe listen --forward-to localhost:3000/api/webhooks/stripe
```

Copy the `whsec_` value into `STRIPE_WEBHOOK_SECRET`.

### 5. Run Locally

```bash
npm run dev
# → http://localhost:3000
```

---

## Environment Variables — Where to Get Each Key

### Clerk (Authentication)
1. Go to [dashboard.clerk.com](https://dashboard.clerk.com)
2. Create application → "Silence the Noise"
3. Copy **Publishable Key** and **Secret Key**
4. Under Webhooks → create endpoint: `https://samuelewilson.org/api/webhooks/clerk`
5. Subscribe to: `user.created`, `user.updated`
6. Copy signing secret → `CLERK_WEBHOOK_SECRET`

### Stripe (Payments)
1. Go to [dashboard.stripe.com](https://dashboard.stripe.com)
2. Developers → API Keys → copy live keys
3. Run `npm run stripe:setup` to create products (uses your secret key)
4. Webhooks → Add endpoint: `https://samuelewilson.org/api/webhooks/stripe`
5. Subscribe to events listed in `scripts/stripe-setup.ts`

### Sanity (CMS)
1. Go to [sanity.io](https://sanity.io) → Create project
2. Name: "Silence the Noise"
3. Dataset: `production`
4. API → Tokens → Create token (Editor role)
5. Deploy the schemas from `docs/sanity-schemas.ts` to your Sanity project

### Resend (Email)
1. Go to [resend.com](https://resend.com)
2. Verify your domain: `samuelewilson.org`
3. API Keys → Create key
4. Audiences → Create: "Newsletter", "Members", "Course Students"
5. Copy audience IDs into env vars

---

## Site Architecture

```
samuelewilson.org/
│
├── /                          ← Full Silence the Noise™ homepage
├── /framework                 ← Seven Pillars overview
├── /journey                   ← Interactive 7-step path
├── /pillars                   ← Individual pillar pages
│
├── /anxiety                   ← Topic hub (aggregates all anxiety content)
├── /depression                ← Topic hub
├── /ptsd                      ← Topic hub
├── /faith                     ← Topic hub
├── /body                      ← Topic hub
├── /purpose                   ← Topic hub
│
├── /articles                  ← Searchable article library
│   └── /articles/[slug]       ← Individual articles (SEO-optimized)
├── /devotionals               ← Devotional library
│   └── /devotionals/[slug]    ← Individual devotionals
├── /podcast                   ← Episode library
│   └── /podcast/[episode]     ← Individual episodes
├── /videos                    ← Video series library
│
├── /resources                 ← Searchable resource library
├── /speaking                  ← Speaking page + inquiry form
├── /about                     ← About Dr. Wilson
├── /contact                   ← Contact form
│
├── /membership                ← Pricing + join
├── /course                    ← Course landing page
├── /dashboard                 ← Member dashboard (auth-gated)
├── /account                   ← Account settings
│
└── /api/
    ├── /api/stripe/checkout   ← Create Stripe checkout session
    ├── /api/stripe/portal     ← Stripe customer portal
    ├── /api/webhooks/stripe   ← Handle Stripe events
    ├── /api/webhooks/clerk    ← Handle Clerk events
    └── /api/email/subscribe   ← Newsletter signup
```

---

## Content Architecture

Every piece of content is tagged with:

1. **Topic Category** — Anxiety · Depression · PTSD · Faith · Body · Purpose
2. **Framework Pillars** — Awareness → Surrender → Identity → Discipline → Renewal → Compassion → Integration
3. **Member Only** — toggle to gate behind membership
4. **Framework Badge** — auto-applied to every article, devotional, podcast episode

### Adding Content

All content is managed through **Sanity Studio** at `https://samuelewilson.sanity.studio/`.

When you publish an article in Sanity:
- It automatically appears on the correct topic hub page
- The framework badge is added automatically
- Related content is surfaced automatically by matching category
- SEO metadata is applied per-article

---

## Monetization Flow

```
User visits article (member-only) 
  → Sees gated content with MemberGate component
  → Clicks "Join the Community"
  → /membership page (pricing table)
  → Clicks plan → /api/stripe/checkout
  → Stripe Checkout (hosted)
  → Payment success → /dashboard?success=true
  → Stripe webhook → sendMembershipWelcome email
  → User has full access
```

---

## Deployment — Vercel

### First Deploy

```bash
# Install Vercel CLI
npm i -g vercel

# Link project
vercel link

# Deploy
vercel --prod
```

### Environment Variables on Vercel

Go to: Vercel Dashboard → Project → Settings → Environment Variables

Add all variables from `.env.example` with production values.

### Custom Domain

Vercel Dashboard → Project → Settings → Domains → Add `samuelewilson.org`

---

## URL Preservation

All existing `samuelewilson.org` URLs are preserved via `next.config.ts` redirects:

- `/#framework` → `/framework`
- `/#anxiety` → `/anxiety`
- `/#ptsd` → `/ptsd`
- `/#about` → `/about`
- `/#speaking` → `/speaking`
- `/blog/:slug` → `/articles/:slug`

---

## Future-Ready Architecture

The following are architected and ready to wire up:

| Feature | Status | Integration |
|---|---|---|
| Membership | ✅ Ready | Stripe + Clerk |
| Course | ✅ Ready | Stripe + custom player |
| Community | 🔌 Slot ready | Circle.so or Mighty Networks |
| Coaching Booking | 🔌 Slot ready | Calendly or Cal.com |
| PDF Downloads | 🔌 Slot ready | Sanity file fields |
| Live Q&A | 🔌 Slot ready | Zoom or StreamYard embed |
| Mobile App | 🔌 Slot ready | React Native / Expo |

---

## Project Structure

```
src/
├── app/                    # Next.js App Router pages
│   ├── api/               # API routes
│   ├── articles/          # Article pages
│   ├── dashboard/         # Member dashboard
│   ├── membership/        # Pricing page
│   └── ...                # All other pages
├── components/
│   ├── framework/         # FrameworkBadge, PillarProgress, RelatedContent
│   ├── layout/            # SiteNav, SiteFooter
│   ├── monetization/      # PricingTable, CheckoutButton, MemberGate, EmailCapture
│   └── ui/                # Shared UI primitives
├── lib/
│   ├── sanity.ts          # CMS client + GROQ queries
│   ├── stripe.ts          # Payment logic
│   ├── email.ts           # Transactional email
│   ├── access.ts          # Auth + membership checks
│   └── analytics.ts       # Event tracking
├── styles/
│   └── globals.css        # Design tokens + global styles
├── types/
│   └── index.ts           # All TypeScript types
├── hooks/                 # Custom React hooks
└── middleware.ts          # Clerk auth middleware
```

---

## Support

- **Technical issues**: open a GitHub issue
- **Content questions**: reply to any email from the platform
- **Billing**: [samuelewilson.org/contact](https://samuelewilson.org/contact)

---

*Built for the Silence the Noise™ platform — samuelewilson.org*  
*© 2026 Samuel E. Wilson, MD. All rights reserved.*
