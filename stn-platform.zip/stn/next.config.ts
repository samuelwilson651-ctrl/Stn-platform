import type { NextConfig } from "next";

const nextConfig: NextConfig = {
  images: {
    remotePatterns: [
      { protocol: "https", hostname: "cdn.sanity.io" },
      { protocol: "https", hostname: "images.unsplash.com" },
    ],
  },
  async redirects() {
    // Preserve all existing samuelewilson.org URLs
    return [
      // Legacy anchor-based URLs → new pages
      { source: "/#framework", destination: "/framework", permanent: true },
      { source: "/#anxiety", destination: "/anxiety", permanent: true },
      { source: "/#ptsd", destination: "/ptsd", permanent: true },
      { source: "/#about", destination: "/about", permanent: true },
      { source: "/#speaking", destination: "/speaking", permanent: true },
      { source: "/7-day-reset", destination: "/resources", permanent: false },
      // Legacy page names
      { source: "/blog/:slug", destination: "/articles/:slug", permanent: true },
      { source: "/post/:slug", destination: "/articles/:slug", permanent: true },
    ];
  },
  async headers() {
    return [
      {
        source: "/(.*)",
        headers: [
          { key: "X-Frame-Options", value: "SAMEORIGIN" },
          { key: "X-Content-Type-Options", value: "nosniff" },
          { key: "Referrer-Policy", value: "strict-origin-when-cross-origin" },
        ],
      },
    ];
  },
};

export default nextConfig;
