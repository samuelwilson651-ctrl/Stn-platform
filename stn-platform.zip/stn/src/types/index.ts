// ═══════════════════════════════════════════════════════════════
// SILENCE THE NOISE™ — Core Types
// ═══════════════════════════════════════════════════════════════

// ── Framework ──────────────────────────────────────────────────

export type Pillar =
  | "awareness"
  | "surrender"
  | "identity"
  | "discipline"
  | "renewal"
  | "compassion"
  | "integration";

export type TopicCategory =
  | "anxiety"
  | "depression"
  | "ptsd"
  | "faith"
  | "body"
  | "purpose";

export const PILLARS: Record<Pillar, { number: number; title: string; tagline: string }> = {
  awareness:    { number: 1, title: "Awareness",            tagline: "Recognize the noise before it controls you." },
  surrender:    { number: 2, title: "Surrender",            tagline: "Release what was never yours to carry." },
  identity:     { number: 3, title: "Identity",             tagline: "You are not your diagnosis, your trauma, or your past." },
  discipline:   { number: 4, title: "Discipline",           tagline: "Small daily actions create transformation." },
  renewal:      { number: 5, title: "Renewal Under Pressure", tagline: "Storms reveal foundations — and become places of growth." },
  compassion:   { number: 6, title: "Compassion",           tagline: "Healing rarely happens in isolation." },
  integration:  { number: 7, title: "Integration",          tagline: "Mind, body, spirit, purpose, and relationships aligned." },
};

export const TOPICS: Record<TopicCategory, { title: string; icon: string; description: string; pillars: Pillar[] }> = {
  anxiety:    { title: "Anxiety",                  icon: "🌀", description: "Fear of tomorrow, the cost of uncertainty, and the path to peace.", pillars: ["awareness", "surrender"] },
  depression: { title: "Depression",               icon: "🌧", description: "When the soul grows tired — and the path back to hope.", pillars: ["surrender", "compassion"] },
  ptsd:       { title: "PTSD & Trauma",            icon: "🧩", description: "Trauma is not a life sentence. Integration is possible.", pillars: ["identity", "integration"] },
  faith:      { title: "Faith & Spiritual Renewal",icon: "✝",  description: "Hearing the gentle whisper when the world is shouting.", pillars: ["surrender", "identity"] },
  body:       { title: "Body, Nutrition & Healing",icon: "🌿", description: "Stewardship of the whole person — body, brain, and spirit.", pillars: ["discipline"] },
  purpose:    { title: "Purpose",                  icon: "🧭", description: "From survival mode into the life you were created to live.", pillars: ["integration"] },
};

// ── Content ────────────────────────────────────────────────────

export interface Author {
  name: string;
  credentials: string;
  bio: string;
  image?: SanityImage;
}

export interface SanityImage {
  asset: { _ref: string };
  alt?: string;
  caption?: string;
}

export interface Article {
  _id: string;
  _type: "article";
  title: string;
  slug: { current: string };
  excerpt: string;
  body: PortableTextBlock[];
  coverImage?: SanityImage;
  author: Author;
  publishedAt: string;
  updatedAt?: string;
  category: TopicCategory;
  pillars: Pillar[];
  tags: string[];
  featured: boolean;
  memberOnly: boolean;
  readingTime: number; // minutes
  seo: SEOFields;
}

export interface Devotional {
  _id: string;
  _type: "devotional";
  title: string;
  slug: { current: string };
  scripture: string;
  scriptureReference: string;
  reflection: PortableTextBlock[];
  prayer: string;
  coverImage?: SanityImage;
  publishedAt: string;
  category: TopicCategory;
  pillars: Pillar[];
  theme: DevotionalTheme;
  memberOnly: boolean;
  seo: SEOFields;
}

export type DevotionalTheme =
  | "scripture" | "healing" | "justice" | "identity" | "prayer" | "gratitude" | "purpose";

export interface PodcastEpisode {
  _id: string;
  _type: "podcast";
  title: string;
  slug: { current: string };
  episodeNumber: number;
  description: string;
  audioUrl: string;
  duration: number; // seconds
  transcript?: PortableTextBlock[];
  coverImage?: SanityImage;
  publishedAt: string;
  category: TopicCategory;
  pillars: Pillar[];
  memberOnly: boolean;
  seo: SEOFields;
}

export interface VideoSeries {
  _id: string;
  _type: "videoSeries";
  title: string;
  slug: { current: string };
  seriesNumber: number;
  description: string;
  videoUrl: string;
  thumbnailUrl?: SanityImage;
  duration: number;
  publishedAt: string;
  category: TopicCategory;
  pillars: Pillar[];
  memberOnly: boolean;
  seo: SEOFields;
}

export interface Resource {
  _id: string;
  _type: "resource";
  title: string;
  slug: { current: string };
  description: string;
  resourceType: ResourceType;
  fileUrl?: string;
  externalUrl?: string;
  coverImage?: SanityImage;
  category: TopicCategory;
  pillars: Pillar[];
  memberOnly: boolean;
  comingSoon: boolean;
  publishedAt: string;
}

export type ResourceType = "pdf" | "guide" | "worksheet" | "audio" | "video" | "link";

export interface PortableTextBlock {
  _type: string;
  _key: string;
  children?: Array<{ _key: string; _type: string; text?: string; marks?: string[] }>;
  markDefs?: Array<{ _key: string; _type: string; href?: string }>;
  style?: string;
}

export interface SEOFields {
  metaTitle?: string;
  metaDescription?: string;
  ogImage?: SanityImage;
  noIndex?: boolean;
}

// ── Monetization ───────────────────────────────────────────────

export type ProductType =
  | "membership_monthly"
  | "membership_annual"
  | "course_stn"
  | "coaching_session"
  | "consultation";

export interface Product {
  id: ProductType;
  name: string;
  description: string;
  price: number; // in cents
  interval?: "month" | "year";
  stripePriceId: string;
  features: string[];
  featured?: boolean;
  tag?: string;
}

export const PRODUCTS: Record<ProductType, Omit<Product, "stripePriceId">> = {
  membership_monthly: {
    id: "membership_monthly",
    name: "Community Membership",
    description: "Full access to the Silence the Noise™ community and all member content.",
    price: 1700,
    interval: "month",
    tag: "Most Popular",
    featured: true,
    features: [
      "All member-only articles & devotionals",
      "Full podcast & video library",
      "Resource library (PDFs, guides, worksheets)",
      "Community discussion boards",
      "Monthly live Q&A with Dr. Wilson",
      "7-Day Reset Protocol (digital)",
    ],
  },
  membership_annual: {
    id: "membership_annual",
    name: "Annual Membership",
    description: "Everything in monthly — save 35% with an annual commitment.",
    price: 13200,
    interval: "year",
    tag: "Best Value",
    features: [
      "Everything in monthly membership",
      "Save 35% vs. monthly",
      "Priority access to new content",
      "Annual framework review session (group)",
    ],
  },
  course_stn: {
    id: "course_stn",
    name: "Silence the Noise™ Course",
    description: "A structured, seven-module journey through the complete framework.",
    price: 29700,
    features: [
      "7 in-depth video modules",
      "Workbooks for each pillar",
      "Lifetime access",
      "Private course community",
      "Certificate of completion",
    ],
  },
  coaching_session: {
    id: "coaching_session",
    name: "Coaching Session",
    description: "One 60-minute session with a certified Silence the Noise™ coach.",
    price: 19700,
    features: [
      "60-minute video session",
      "Pre-session intake questionnaire",
      "Session recording",
      "Follow-up resources",
    ],
  },
  consultation: {
    id: "consultation",
    name: "Physician Consultation",
    description: "One-on-one time with Dr. Samuel E. Wilson, MD.",
    price: 49700,
    features: [
      "45-minute consultation with Dr. Wilson",
      "Personalized framework assessment",
      "Written recommendations",
      "Priority email follow-up (30 days)",
    ],
  },
};

// ── User / Auth ────────────────────────────────────────────────

export interface UserProfile {
  clerkUserId: string;
  email: string;
  firstName?: string;
  lastName?: string;
  stripeCustomerId?: string;
  subscription?: UserSubscription;
  purchasedCourses: string[];
  createdAt: string;
}

export interface UserSubscription {
  stripeSubscriptionId: string;
  status: "active" | "canceled" | "past_due" | "trialing";
  plan: "monthly" | "annual";
  currentPeriodEnd: string;
  cancelAtPeriodEnd: boolean;
}

export type MemberAccess = "free" | "member" | "course" | "admin";

// ── Navigation ─────────────────────────────────────────────────

export interface NavItem {
  label: string;
  href: string;
  children?: NavItem[];
}

// ── Email ──────────────────────────────────────────────────────

export interface EmailSubscriber {
  email: string;
  firstName?: string;
  source: "homepage" | "article" | "devotional" | "popup" | "checkout";
  tags?: string[];
}
