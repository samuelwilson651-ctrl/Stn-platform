import { clerkMiddleware, createRouteMatcher } from "@clerk/nextjs/server";
import { NextResponse } from "next/server";

// Routes that require authentication
const isProtectedRoute = createRouteMatcher([
  "/dashboard(.*)",
  "/account(.*)",
  "/course(.*)",
]);

// Routes that require active membership
const isMemberRoute = createRouteMatcher([
  "/dashboard(.*)",
  "/course(.*)",
]);

export default clerkMiddleware(async (auth, req) => {
  // Protect auth-required routes
  if (isProtectedRoute(req)) {
    await auth.protect();
  }

  // For member-gated routes, redirect to membership page if not subscribed
  // Note: full membership check happens in the page component (server-side)
  // Middleware just ensures they're logged in first
  if (isMemberRoute(req)) {
    await auth.protect({
      unauthenticatedUrl: `${req.nextUrl.origin}/login?redirect=${req.nextUrl.pathname}`,
    });
  }

  return NextResponse.next();
});

export const config = {
  matcher: [
    // Skip Next.js internals and static files
    "/((?!_next|[^?]*\\.(?:html?|css|js(?!on)|jpe?g|webp|png|gif|svg|ttf|woff2?|ico|csv|docx?|xlsx?|zip|webmanifest)).*)",
    // Always run for API routes
    "/(api|trpc)(.*)",
  ],
};
