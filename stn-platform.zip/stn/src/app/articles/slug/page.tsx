import type { Metadata } from "next";
import { notFound } from "next/navigation";
import Image from "next/image";
import { getArticleBySlug, getAllArticles, urlFor } from "@/lib/sanity";
import { getUserAccess } from "@/lib/access";
import { FrameworkBadge, RelatedContent } from "@/components/framework/FrameworkBadge";
import { MemberGate, JourneyCTA } from "@/components/monetization";
import type { Article } from "@/types";

// ── Static params for SSG ──────────────────────────────────────
export async function generateStaticParams() {
  const articles: Article[] = await getAllArticles();
  return articles.map((a) => ({ slug: a.slug.current }));
}

// ── Metadata ───────────────────────────────────────────────────
export async function generateMetadata({
  params,
}: {
  params: Promise<{ slug: string }>;
}): Promise<Metadata> {
  const { slug } = await params;
  const article: Article | null = await getArticleBySlug(slug);
  if (!article) return { title: "Article Not Found" };

  const ogImage = article.seo?.ogImage
    ? urlFor(article.seo.ogImage).width(1200).height(630).url()
    : article.coverImage
    ? urlFor(article.coverImage).width(1200).height(630).url()
    : undefined;

  return {
    title: article.seo?.metaTitle ?? article.title,
    description: article.seo?.metaDescription ?? article.excerpt,
    openGraph: {
      title: article.title,
      description: article.excerpt,
      images: ogImage ? [{ url: ogImage }] : [],
      type: "article",
      publishedTime: article.publishedAt,
      authors: [article.author.name],
    },
    robots: article.seo?.noIndex ? { index: false } : undefined,
  };
}

// ── Page ───────────────────────────────────────────────────────
export default async function ArticlePage({
  params,
}: {
  params: Promise<{ slug: string }>;
}) {
  const { slug } = await params;
  const [article, access] = await Promise.all([
    getArticleBySlug(slug) as Promise<Article & { related: Article[] }>,
    getUserAccess(),
  ]);

  if (!article) notFound();

  const canRead = !article.memberOnly || access.isMember;
  const coverImageUrl = article.coverImage
    ? urlFor(article.coverImage).width(1200).height(630).url()
    : null;

  // Structured data for SEO
  const jsonLd = {
    "@context": "https://schema.org",
    "@type": "Article",
    headline: article.title,
    description: article.excerpt,
    author: {
      "@type": "Person",
      name: article.author.name,
      jobTitle: article.author.credentials,
    },
    publisher: {
      "@type": "Organization",
      name: "Silence the Noise™",
      url: "https://samuelewilson.org",
    },
    datePublished: article.publishedAt,
    dateModified: article.updatedAt ?? article.publishedAt,
    image: coverImageUrl ?? undefined,
    url: `https://samuelewilson.org/articles/${slug}`,
  };

  return (
    <>
      <script type="application/ld+json" dangerouslySetInnerHTML={{ __html: JSON.stringify(jsonLd) }} />

      <article>
        {/* Header */}
        <header style={{ background: "var(--navy)", padding: "6rem 2rem 4rem" }}>
          <div className="container-narrow">
            <FrameworkBadge
              pillars={article.pillars}
              category={article.category}
              variant="dark"
              className="mb-6"
            />
            <h1 style={{
              fontFamily: "var(--font-cormorant)",
              fontSize: "clamp(2.25rem, 5vw, 3.75rem)",
              fontWeight: 600,
              color: "white",
              lineHeight: 1.15,
              marginTop: "1.25rem",
            }}>
              {article.title}
            </h1>
            <p style={{
              fontFamily: "var(--font-cormorant)",
              fontStyle: "italic",
              fontSize: "1.2rem",
              color: "rgba(255,255,255,0.6)",
              marginTop: "1rem",
              lineHeight: 1.65,
            }}>
              {article.excerpt}
            </p>
            <div className="article-meta">
              <span>{article.author.name}, {article.author.credentials}</span>
              <span className="meta-dot">·</span>
              <time dateTime={article.publishedAt}>
                {new Date(article.publishedAt).toLocaleDateString("en-US", {
                  year: "numeric", month: "long", day: "numeric"
                })}
              </time>
              <span className="meta-dot">·</span>
              <span>{article.readingTime} min read</span>
              {article.memberOnly && (
                <>
                  <span className="meta-dot">·</span>
                  <span className="member-label">Member Content</span>
                </>
              )}
            </div>
          </div>
        </header>

        {/* Cover image */}
        {coverImageUrl && (
          <div style={{ maxHeight: "480px", overflow: "hidden" }}>
            <Image
              src={coverImageUrl}
              alt={article.coverImage?.alt ?? article.title}
              width={1200}
              height={630}
              priority
              className="w-full object-cover"
            />
          </div>
        )}

        {/* Body */}
        <div style={{ background: "white" }}>
          <div className="container-narrow" style={{ padding: "4rem 2rem" }}>
            {canRead ? (
              <ArticleBody blocks={article.body} />
            ) : (
              <MemberGate
                title="Continue Reading"
                preview={
                  article.body?.length > 0 ? (
                    <div className="prose-stn" style={{ opacity: 0.9 }}>
                      {/* Show first block as preview */}
                      <p style={{ fontFamily: "var(--font-cormorant)", fontSize: "1.15rem", lineHeight: 1.9 }}>
                        {article.excerpt}
                      </p>
                    </div>
                  ) : undefined
                }
              />
            )}

            {canRead && (
              <>
                {/* End-of-article framework badge */}
                <div style={{ marginTop: "4rem", paddingTop: "2.5rem", borderTop: "1px solid var(--border)" }}>
                  <FrameworkBadge pillars={article.pillars} category={article.category} />
                </div>

                {/* Related content */}
                {article.related?.length > 0 && (
                  <RelatedContent items={article.related} type="article" />
                )}
              </>
            )}
          </div>
        </div>
      </article>

      <JourneyCTA />

      <style jsx>{`
        .article-meta {
          display: flex; align-items: center; flex-wrap: wrap; gap: 0.5rem;
          font-family: var(--font-inter); font-size: 0.75rem; letter-spacing: 0.08em;
          color: rgba(255,255,255,0.4); margin-top: 1.5rem;
        }
        .meta-dot { opacity: 0.4; }
        .member-label {
          background: rgba(201,168,76,0.15); color: var(--gold);
          padding: 0.15rem 0.5rem; border-radius: 2px; font-size: 0.65rem; letter-spacing: 0.1em;
        }
      `}</style>
    </>
  );
}

// ── Portable Text renderer ─────────────────────────────────────
// Replace with @portabletext/react for production
function ArticleBody({ blocks }: { blocks: Article["body"] }) {
  if (!blocks?.length) return null;
  return (
    <div className="prose-stn">
      {blocks.map((block) => {
        if (block._type === "block") {
          const text = block.children?.map((c) => c.text).join("") ?? "";
          const Tag = (block.style === "h2" ? "h2" : block.style === "h3" ? "h3" : "p") as keyof JSX.IntrinsicElements;
          return <Tag key={block._key}>{text}</Tag>;
        }
        return null;
      })}
    </div>
  );
}

// Temp fix: declare JSX namespace
declare namespace JSX {
  interface IntrinsicElements {
    [elemName: string]: React.DetailedHTMLProps<React.HTMLAttributes<HTMLElement>, HTMLElement>;
  }
}
