import { redirect } from "next/navigation";
import Link from "next/link";
import { requireAuth } from "@/lib/access";
import { createPortalSession } from "@/lib/stripe";
import { currentUser } from "@clerk/nextjs/server";

export const metadata = {
  title: "Dashboard",
  robots: { index: false },
};

export default async function DashboardPage({
  searchParams,
}: {
  searchParams: Promise<{ success?: string }>;
}) {
  await requireAuth();
  const user = await currentUser();
  const params = await searchParams;
  const justJoined = params.success === "true";
  const firstName = user?.firstName ?? "Friend";
  const stripeCustomerId = user?.privateMetadata?.stripeCustomerId as string | undefined;

  return (
    <div style={{ minHeight: "100vh", background: "var(--cream)" }}>

      {/* Welcome banner */}
      <div style={{ background: "var(--navy)", padding: "4rem 2rem 3rem" }}>
        <div className="container-site">
          <p className="label-text" style={{ color: "var(--gold)" }}>Your Dashboard</p>
          <h1 style={{ fontFamily: "var(--font-cormorant)", fontSize: "clamp(2rem, 4vw, 3rem)", color: "white", fontWeight: 600 }}>
            {justJoined ? `Welcome to the community, ${firstName}.` : `Welcome back, ${firstName}.`}
          </h1>
          {justJoined && (
            <p style={{ fontFamily: "var(--font-cormorant)", fontStyle: "italic", color: "rgba(255,255,255,0.6)", fontSize: "1.1rem", marginTop: "0.5rem" }}>
              Your membership is active. Begin your journey below.
            </p>
          )}
        </div>
      </div>

      <div className="container-site section-pad">
        <div className="dashboard-grid">

          {/* Quick links */}
          <div className="dash-section">
            <h2 className="dash-heading">Start Here</h2>
            <div className="dash-links">
              {[
                { label: "The Journey Path", href: "/journey", desc: "Your 7-step framework roadmap", icon: "→" },
                { label: "Articles", href: "/articles", desc: "All published writings", icon: "📄" },
                { label: "Devotionals", href: "/devotionals", desc: "Daily scripture-rooted reflections", icon: "✝" },
                { label: "Podcast", href: "/podcast", desc: "The Whole Person Podcast", icon: "🎙" },
                { label: "Video Series", href: "/videos", desc: "Teaching video library", icon: "🎬" },
                { label: "Resources", href: "/resources", desc: "Guides, PDFs, tools", icon: "📚" },
              ].map((item) => (
                <Link key={item.href} href={item.href} className="dash-link-card">
                  <span className="dash-link-icon">{item.icon}</span>
                  <div>
                    <div className="dash-link-title">{item.label}</div>
                    <div className="dash-link-desc">{item.desc}</div>
                  </div>
                  <span className="dash-link-arrow">→</span>
                </Link>
              ))}
            </div>
          </div>

          {/* Account */}
          <div>
            <div className="dash-section">
              <h2 className="dash-heading">Your Account</h2>
              <div className="dash-account-card">
                <p className="dash-account-email">{user?.emailAddresses?.[0]?.emailAddress}</p>
                <p className="dash-account-name">{[user?.firstName, user?.lastName].filter(Boolean).join(" ")}</p>
                <div style={{ marginTop: "1.25rem", display: "flex", flexDirection: "column", gap: "0.5rem" }}>
                  {stripeCustomerId && (
                    <PortalButton customerId={stripeCustomerId} />
                  )}
                  <Link href="/account" className="btn btn-outline-dark" style={{ justifyContent: "center" }}>
                    Manage Profile
                  </Link>
                </div>
              </div>
            </div>

            {/* Framework progress */}
            <div className="dash-section" style={{ marginTop: "1.5rem" }}>
              <h2 className="dash-heading">Framework Journey</h2>
              <div className="dash-pillars">
                {[
                  { num: "I", label: "Awareness", href: "/journey#awareness" },
                  { num: "II", label: "Surrender", href: "/journey#surrender" },
                  { num: "III", label: "Identity", href: "/journey#identity" },
                  { num: "IV", label: "Discipline", href: "/journey#discipline" },
                  { num: "V", label: "Renewal", href: "/journey#renewal" },
                  { num: "VI", label: "Compassion", href: "/journey#compassion" },
                  { num: "VII", label: "Integration", href: "/journey#integration" },
                ].map((p) => (
                  <Link key={p.num} href={p.href} className="dash-pillar">
                    <span className="dash-pillar-num">{p.num}</span>
                    <span className="dash-pillar-label">{p.label}</span>
                  </Link>
                ))}
              </div>
            </div>
          </div>

        </div>
      </div>

      <style jsx>{`
        .dashboard-grid { display: grid; grid-template-columns: 1fr 340px; gap: 3rem; align-items: start; }
        @media (max-width: 900px) { .dashboard-grid { grid-template-columns: 1fr; } }
        .dash-section { background: white; border: 1px solid var(--border); border-radius: 2px; padding: 2rem; }
        .dash-heading { font-family: var(--font-cormorant); font-size: 1.25rem; font-weight: 600; color: var(--navy); margin-bottom: 1.25rem; padding-bottom: 0.75rem; border-bottom: 1px solid var(--border); }
        .dash-links { display: flex; flex-direction: column; gap: 0; }
        .dash-link-card { display: flex; align-items: center; gap: 1rem; padding: 1rem; border-bottom: 1px solid var(--border); transition: background 0.15s; }
        .dash-link-card:last-child { border-bottom: none; }
        .dash-link-card:hover { background: var(--cream); }
        .dash-link-icon { font-size: 1.2rem; min-width: 2rem; text-align: center; }
        .dash-link-title { font-family: var(--font-cormorant); font-size: 1rem; font-weight: 600; color: var(--navy); }
        .dash-link-desc { font-family: var(--font-inter); font-size: 0.72rem; color: var(--muted); margin-top: 0.1rem; }
        .dash-link-arrow { margin-left: auto; color: var(--gold); font-size: 0.85rem; }
        .dash-account-card { background: var(--cream); border-radius: 2px; padding: 1.25rem; }
        .dash-account-email { font-family: var(--font-inter); font-size: 0.82rem; color: var(--muted); }
        .dash-account-name { font-family: var(--font-cormorant); font-size: 1.1rem; font-weight: 600; color: var(--navy); }
        .dash-pillars { display: flex; flex-direction: column; gap: 0; }
        .dash-pillar { display: flex; align-items: center; gap: 1rem; padding: 0.75rem 0; border-bottom: 1px solid var(--border); transition: padding-left 0.2s; }
        .dash-pillar:last-child { border-bottom: none; }
        .dash-pillar:hover { padding-left: 0.25rem; }
        .dash-pillar-num { font-family: var(--font-cinzel); font-size: 0.7rem; color: var(--gold); min-width: 2.5rem; }
        .dash-pillar-label { font-family: var(--font-inter); font-size: 0.78rem; color: var(--navy); letter-spacing: 0.06em; }
      `}</style>
    </div>
  );
}

// Client component for Stripe portal redirect
async function PortalButton({ customerId }: { customerId: string }) {
  "use client";
  // This is a server component — portal redirect handled via API
  return (
    <form action="/api/stripe/portal" method="POST">
      <input type="hidden" name="customerId" value={customerId} />
      <button type="submit" className="btn btn-outline-dark" style={{ width: "100%", justifyContent: "center" }}>
        Manage Billing
      </button>
    </form>
  );
}
