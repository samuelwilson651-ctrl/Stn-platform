import type { Metadata } from "next";
import Link from "next/link";
import { PricingTable } from "@/components/monetization";

export const metadata: Metadata = {
  title: "Join the Community",
  description: "Join the Silence the Noise™ community — full access to articles, devotionals, podcast, courses, and more.",
};

export default function MembershipPage() {
  return (
    <div style={{ background: "var(--cream)" }}>

      {/* Hero */}
      <section style={{ background: "var(--navy)", padding: "7rem 2rem 5rem", textAlign: "center" }}>
        <div className="container-narrow">
          <p className="label-text" style={{ color: "var(--gold)", textAlign: "center" }}>Community Membership</p>
          <h1 style={{ fontFamily: "var(--font-cormorant)", fontSize: "clamp(2.5rem, 5vw, 4rem)", fontWeight: 600, color: "white", lineHeight: 1.2, marginBottom: "1rem" }}>
            Join the<br/>Silence the Noise™ Community
          </h1>
          <div className="gold-rule gold-rule-center" />
          <p className="serif-body" style={{ color: "rgba(255,255,255,0.6)", maxWidth: 560, margin: "0 auto" }}>
            Full access to the physician-led, faith-centered library — articles, devotionals, podcast, video series, resources, and a growing community of people committed to healing, alignment, and purpose.
          </p>
        </div>
      </section>

      {/* Pricing */}
      <section className="section-pad">
        <div className="container-site">
          <PricingTable />
        </div>
      </section>

      {/* What's included */}
      <section style={{ background: "var(--navy)", padding: "6rem 2rem" }}>
        <div className="container-site">
          <div style={{ textAlign: "center", marginBottom: "3rem" }}>
            <p className="label-text" style={{ color: "var(--gold)" }}>What's Included</p>
            <h2 className="section-title-light">Everything in the Framework</h2>
            <div className="gold-rule gold-rule-center" />
          </div>
          <div className="includes-grid">
            {[
              { icon: "📄", title: "Full Article Library", desc: "Every published article, organized by topic and pillar" },
              { icon: "✝", title: "50+ Devotionals", desc: "Scripture · Reflection · Prayer — tagged by theme and pillar" },
              { icon: "🎙", title: "Complete Podcast", desc: "All episodes of The Whole Person Podcast" },
              { icon: "🎬", title: "Video Series", desc: "All 5 teaching series with future series included" },
              { icon: "📚", title: "Resource Library", desc: "PDFs, guides, worksheets, and the 7-Day Reset Protocol" },
              { icon: "👥", title: "Community", desc: "Discussion boards, accountability, and shared journey" },
              { icon: "🎤", title: "Monthly Q&A", desc: "Live session with Dr. Wilson — submit your questions" },
              { icon: "📱", title: "Devotional App", desc: "Full access to all app content" },
            ].map((item) => (
              <div key={item.title} className="includes-card">
                <div className="includes-icon">{item.icon}</div>
                <h3>{item.title}</h3>
                <p>{item.desc}</p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* FAQ */}
      <section className="section-pad">
        <div className="container-narrow">
          <h2 className="section-title" style={{ textAlign: "center", marginBottom: "3rem" }}>Questions</h2>
          <div className="faq-list">
            {[
              {
                q: "Is there a free trial?",
                a: "New members receive a 7-day free trial on the monthly plan. You will not be charged until the trial ends, and you can cancel at any time.",
              },
              {
                q: "Can I cancel anytime?",
                a: "Yes. Cancel from your dashboard at any time. You retain access through the end of your billing period.",
              },
              {
                q: "Is the course included in membership?",
                a: "The Silence the Noise™ Course is a separate, one-time purchase. Membership includes the full content library, community, and monthly Q&A.",
              },
              {
                q: "What is your refund policy?",
                a: "If you are not satisfied within 30 days of your first payment, contact us for a full refund — no questions asked.",
              },
              {
                q: "Is this content faith-based?",
                a: "Yes — and intentionally so. The framework integrates Christian scripture with clinical neuroscience. It is designed for people of faith and those who are open to it.",
              },
            ].map((faq) => (
              <details key={faq.q} className="faq-item">
                <summary className="faq-q">{faq.q}</summary>
                <p className="faq-a">{faq.a}</p>
              </details>
            ))}
          </div>
          <div style={{ textAlign: "center", marginTop: "3rem" }}>
            <p className="serif-body" style={{ marginBottom: "1.5rem" }}>Still have questions?</p>
            <Link href="/contact" className="btn btn-outline-dark">Contact Us</Link>
          </div>
        </div>
      </section>

      <style jsx>{`
        .includes-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(240px, 1fr)); gap: 1px; background: rgba(201,168,76,0.08); }
        .includes-card { background: var(--navy-mid, #1a2e4a); padding: 2rem 1.75rem; }
        .includes-icon { font-size: 1.5rem; margin-bottom: 0.75rem; }
        .includes-card h3 { font-family: var(--font-cormorant); font-size: 1.1rem; font-weight: 600; color: white; margin-bottom: 0.35rem; }
        .includes-card p { font-family: var(--font-cormorant); font-size: 0.92rem; color: rgba(255,255,255,0.45); font-style: italic; line-height: 1.6; }
        .faq-list { display: flex; flex-direction: column; gap: 0; }
        .faq-item { border-bottom: 1px solid var(--border); padding: 0; }
        .faq-item:first-child { border-top: 1px solid var(--border); }
        .faq-q { font-family: var(--font-cormorant); font-size: 1.1rem; font-weight: 600; color: var(--navy); padding: 1.25rem 0; cursor: pointer; list-style: none; display: flex; justify-content: space-between; align-items: center; }
        .faq-q::after { content: '+'; color: var(--gold); font-family: var(--font-inter); font-size: 1.1rem; }
        details[open] .faq-q::after { content: '−'; }
        .faq-a { font-family: var(--font-cormorant); font-size: 1rem; color: var(--muted); line-height: 1.8; padding-bottom: 1.25rem; font-style: italic; }
      `}</style>
    </div>
  );
}
