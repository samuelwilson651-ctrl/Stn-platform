import { NextRequest, NextResponse } from "next/server";
import { subscribeToNewsletter } from "@/lib/email";
import { z } from "zod";

const schema = z.object({
  email: z.string().email(),
  firstName: z.string().optional(),
  source: z.enum(["homepage", "article", "devotional", "popup", "banner", "checkout"]).default("homepage"),
});

export async function POST(req: NextRequest) {
  try {
    const body = await req.json();
    const { email, firstName, source } = schema.parse(body);

    await subscribeToNewsletter({ email, firstName, source });

    return NextResponse.json({ success: true });
  } catch (err) {
    if (err instanceof z.ZodError) {
      return NextResponse.json({ error: "Invalid email" }, { status: 400 });
    }
    console.error("Subscribe error:", err);
    return NextResponse.json({ error: "Subscription failed" }, { status: 500 });
  }
}
