import { NextRequest, NextResponse } from "next/server";
import { headers } from "next/headers";
import Stripe from "stripe";
import { constructWebhookEvent } from "@/lib/stripe";
import { sendMembershipWelcome, sendCourseAccessEmail, sendConsultationConfirmation } from "@/lib/email";
import { clerkClient } from "@clerk/nextjs/server";

export const runtime = "nodejs";

export async function POST(req: NextRequest) {
  const body = await req.arrayBuffer();
  const signature = (await headers()).get("stripe-signature");

  if (!signature) {
    return NextResponse.json({ error: "No signature" }, { status: 400 });
  }

  let event: Stripe.Event;
  try {
    event = constructWebhookEvent(Buffer.from(body), signature);
  } catch (err) {
    console.error("Webhook signature verification failed:", err);
    return NextResponse.json({ error: "Invalid signature" }, { status: 400 });
  }

  try {
    switch (event.type) {

      // ── Checkout completed ─────────────────────────────────
      case "checkout.session.completed": {
        const session = event.data.object as Stripe.Checkout.Session;
        const { userId, productType } = session.metadata ?? {};
        const customerEmail = session.customer_details?.email ?? "";
        const customerName = session.customer_details?.name ?? "";

        if (userId) {
          // Store stripeCustomerId on Clerk user
          const client = await clerkClient();
          await client.users.updateUserMetadata(userId, {
            privateMetadata: {
              stripeCustomerId: session.customer,
            },
          });

          // Send appropriate welcome email
          if (productType?.startsWith("membership")) {
            const plan = productType.includes("annual") ? "Annual" : "Monthly";
            await sendMembershipWelcome(customerEmail, customerName.split(" ")[0] ?? "Friend", plan);
          } else if (productType === "course_stn") {
            await sendCourseAccessEmail(customerEmail, customerName.split(" ")[0] ?? "Friend");
          } else if (productType === "consultation") {
            await sendConsultationConfirmation(customerEmail, customerName.split(" ")[0] ?? "Friend");
          }
        }
        break;
      }

      // ── Subscription created ───────────────────────────────
      case "customer.subscription.created":
      case "customer.subscription.updated": {
        const sub = event.data.object as Stripe.Subscription;
        console.log("Subscription updated:", sub.id, sub.status);
        // TODO: sync subscription status to your database / Clerk metadata
        break;
      }

      // ── Subscription canceled ──────────────────────────────
      case "customer.subscription.deleted": {
        const sub = event.data.object as Stripe.Subscription;
        console.log("Subscription canceled:", sub.id);
        // TODO: revoke member access in your database
        break;
      }

      // ── Payment failed ─────────────────────────────────────
      case "invoice.payment_failed": {
        const invoice = event.data.object as Stripe.Invoice;
        console.warn("Payment failed:", invoice.id, invoice.customer_email);
        // TODO: send payment failed email
        break;
      }

      default:
        // Unhandled event type — log and ignore
        console.log("Unhandled Stripe event:", event.type);
    }
  } catch (err) {
    console.error("Webhook handler error:", err);
    return NextResponse.json({ error: "Handler error" }, { status: 500 });
  }

  return NextResponse.json({ received: true });
}
