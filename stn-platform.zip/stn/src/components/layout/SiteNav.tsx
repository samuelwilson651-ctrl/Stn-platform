"use client";

import { useState, useEffect, useRef } from "react";
import Link from "next/link";
import { usePathname } from "next/navigation";
import { SignedIn, SignedOut, UserButton } from "@clerk/nextjs";

const NAV = [
  {
    label: "The Framework",
    items: [
      { label: "Overview", href: "/framework", icon: "✦" },
      { label: "The Journey Path", href: "/journey", icon: "→" },
      { label: "Teachings", href: "/teachings", icon: "📖" },
      { label: "Seven Pillars", href: "/pillars", icon: "⬡" },
    ],
  },
  {
    label: "Topics",
    items: [
      { label: "Anxiety", href: "/anxiety", icon: "🌀" },
      { label: "Depression", href: "/depression", icon: "🌧" },
      { label: "PTSD & Trauma", href: "/ptsd", icon: "🧩" },
      { label: "Faith & Renewal", href: "/faith", icon: "✝" },
      { label: "Body & Nutrition", href: "/body", icon: "🌿" },
      { label: "Purpose", href: "/purpose", icon: "🧭" },
    ],
  },
  { label: "Articles", href: "/articles" },
  { label: "Devotionals", href: "/devotionals" },
  {
    label: "Media",
    items: [
      { label: "Podcast", href: "/podcast", icon: "🎙" },
      { label: "Video Series", href: "/videos", icon: "🎬" },
      { label: "Speaking", href: "/speaking", icon: "🏛" },
    ],
  },
  { label: "Resources", href: "/resources" },
  { label: "About", href: "/about" },
];

export function SiteNav() {
  const pathname = usePathname();
  const [open, setOpen] = useState<number | null>(null);
  const [mobileOpen, setMobileOpen] = useState(false);
  const [scrolled, setScrolled] = useState(false);
  const navRef = useRef<HTMLElement>(null);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 20);
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  useEffect(() => {
    const handleKey = (e: KeyboardEvent) => {
      if (e.key === "Escape") { setOpen(null); setMobileOpen(false); }
    };
    document.addEventListener("keydown", handleKey);
    return () => document.removeEventListener("keydown", handleKey);
  }, []);

  useEffect(() => {
    const handleClick = (e: MouseEvent) => {
      if (navRef.current && !navRef.current.contains(e.target as Node)) {
        setOpen(null);
      }
    };
    document.addEventListener("click", handleClick);
    return () => document.removeEventListener("click", handleClick);
  }, []);

  useEffect(() => {
    setOpen(null);
    setMobileOpen(false);
  }, [pathname]);

  useEffect(() => {
    document.body.style.overflow = mobileOpen ? "hidden" : "";
    return () => { document.body.style.overflow = ""; };
  }, [mobileOpen]);

  return (
    <>
      <nav
        ref={navRef}
        className="sticky top-0 z-50 transition-shadow duration-300"
        style={{
          background: "rgba(15,30,53,0.97)",
          backdropFilter: "blur(16px)",
          borderBottom: "1px solid rgba(201,168,76,0.15)",
          boxShadow: scrolled ? "0 4px 24px rgba(0,0,0,0.2)" : "none",
        }}
        role="navigation"
        aria-label="Main navigation"
      >
        <div className="container-site">
          <div className="flex items-center justify-between h-16">

            {/* Brand */}
            <Link
              href="/"
              className="font-display text-gold tracking-widest text-sm whitespace-nowrap"
              aria-label="Silence the Noise home"
            >
              Silence the Noise<sup className="text-xs">™</sup>
            </Link>

            {/* Desktop Links */}
            <ul className="hidden lg:flex items-center gap-1 list-none" role="list">
              {NAV.map((item, i) => (
                <li key={item.label} className="relative">
                  {"href" in item ? (
                    <Link
                      href={item.href!}
                      className={`nav-link ${pathname === item.href ? "text-gold" : ""}`}
                    >
                      {item.label}
                    </Link>
                  ) : (
                    <>
                      <button
                        className="nav-link flex items-center gap-1"
                        onClick={() => setOpen(open === i ? null : i)}
                        aria-expanded={open === i}
                        aria-haspopup="true"
                      >
                        {item.label}
                        <span style={{ fontSize: "0.55em", opacity: 0.5, transition: "transform 0.2s", transform: open === i ? "rotate(180deg)" : "none" }}>▼</span>
                      </button>
                      {/* Dropdown */}
                      <div
                        className="nav-dropdown"
                        style={{
                          opacity: open === i ? 1 : 0,
                          visibility: open === i ? "visible" : "hidden",
                          transform: open === i ? "translateX(-50%) translateY(0)" : "translateX(-50%) translateY(-8px)",
                        }}
                        role="menu"
                      >
                        {item.items?.map((child) => (
                          <Link
                            key={child.href}
                            href={child.href}
                            className="dropdown-link"
                            role="menuitem"
                          >
                            <span className="opacity-60">{child.icon}</span>
                            {child.label}
                          </Link>
                        ))}
                      </div>
                    </>
                  )}
                </li>
              ))}
            </ul>

            {/* Right side */}
            <div className="flex items-center gap-3">
              <SignedIn>
                <Link href="/dashboard" className="hidden lg:block nav-cta-ghost">Dashboard</Link>
                <UserButton afterSignOutUrl="/" />
              </SignedIn>
              <SignedOut>
                <Link href="/login" className="hidden lg:block nav-cta-ghost">Sign In</Link>
                <Link href="/membership" className="nav-cta">Join</Link>
              </SignedOut>

              {/* Hamburger */}
              <button
                className="lg:hidden flex flex-col gap-1.5 p-1"
                onClick={() => setMobileOpen(!mobileOpen)}
                aria-label={mobileOpen ? "Close menu" : "Open menu"}
                aria-expanded={mobileOpen}
              >
                <span className="hamburger-line" style={{ transform: mobileOpen ? "rotate(45deg) translate(4px, 4px)" : "none" }} />
                <span className="hamburger-line" style={{ opacity: mobileOpen ? 0 : 1 }} />
                <span className="hamburger-line" style={{ transform: mobileOpen ? "rotate(-45deg) translate(4px, -4px)" : "none" }} />
              </button>
            </div>
          </div>
        </div>
      </nav>

      {/* Mobile Nav Overlay */}
      {mobileOpen && (
        <div
          className="fixed inset-0 z-40 flex flex-col overflow-y-auto"
          style={{ background: "var(--navy)", paddingTop: "5rem" }}
          role="dialog"
          aria-label="Mobile navigation"
        >
          <button
            className="absolute top-5 right-5 text-2xl text-white opacity-60"
            onClick={() => setMobileOpen(false)}
            aria-label="Close menu"
          >✕</button>

          <nav className="px-6 pb-8">
            {NAV.map((item) => (
              <div key={item.label}>
                {"href" in item ? (
                  <Link href={item.href!} className="mobile-nav-link">{item.label}</Link>
                ) : (
                  <>
                    <p className="mobile-nav-section">{item.label}</p>
                    {item.items?.map((child) => (
                      <Link key={child.href} href={child.href} className="mobile-nav-link mobile-nav-sub">
                        {child.icon} {child.label}
                      </Link>
                    ))}
                  </>
                )}
              </div>
            ))}
            <div className="mt-6 flex flex-col gap-3">
              <SignedOut>
                <Link href="/membership" className="btn btn-gold text-center justify-center">Join the Community</Link>
                <Link href="/login" className="btn btn-outline-light text-center justify-center">Sign In</Link>
              </SignedOut>
              <SignedIn>
                <Link href="/dashboard" className="btn btn-gold text-center justify-center">My Dashboard</Link>
              </SignedIn>
            </div>
          </nav>
        </div>
      )}

      <style jsx>{`
        .nav-link {
          font-family: var(--font-inter);
          font-size: 0.72rem;
          letter-spacing: 0.09em;
          text-transform: uppercase;
          color: rgba(255,255,255,0.7);
          padding: 0.5rem 0.75rem;
          border-radius: 2px;
          background: none;
          border: none;
          cursor: pointer;
          transition: color 0.2s;
          display: flex; align-items: center;
        }
        .nav-link:hover { color: #e3c87a; }
        .nav-dropdown {
          position: absolute;
          top: calc(100% + 8px);
          left: 50%;
          background: var(--navy-mid, #1a2e4a);
          border: 1px solid rgba(201,168,76,0.15);
          border-radius: 3px;
          min-width: 210px;
          transition: opacity 0.2s, transform 0.2s, visibility 0.2s;
          box-shadow: 0 16px 40px rgba(0,0,0,0.3);
          overflow: hidden;
        }
        .dropdown-link {
          display: flex; align-items: center; gap: 0.6rem;
          padding: 0.75rem 1.25rem;
          font-size: 0.78rem;
          letter-spacing: 0.06em;
          color: rgba(255,255,255,0.75);
          border-bottom: 1px solid rgba(255,255,255,0.05);
          transition: color 0.15s, background 0.15s;
          font-family: var(--font-inter);
        }
        .dropdown-link:last-child { border-bottom: none; }
        .dropdown-link:hover { color: var(--gold, #c9a84c); background: rgba(201,168,76,0.05); }
        .nav-cta {
          font-family: var(--font-inter);
          font-size: 0.7rem;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          font-weight: 600;
          background: var(--gold, #c9a84c);
          color: var(--navy, #0f1e35);
          padding: 0.45rem 1.1rem;
          border-radius: 2px;
          transition: background 0.2s;
        }
        .nav-cta:hover { background: #e3c87a; }
        .nav-cta-ghost {
          font-family: var(--font-inter);
          font-size: 0.7rem;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: rgba(255,255,255,0.5);
          transition: color 0.2s;
        }
        .nav-cta-ghost:hover { color: rgba(255,255,255,0.85); }
        .hamburger-line {
          width: 22px; height: 1.5px;
          background: rgba(255,255,255,0.7);
          display: block;
          transition: all 0.3s;
          transform-origin: center;
        }
        .mobile-nav-link {
          display: block;
          font-family: var(--font-inter);
          font-size: 0.82rem;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: rgba(255,255,255,0.75);
          padding: 1rem 0;
          border-bottom: 1px solid rgba(255,255,255,0.06);
          transition: color 0.2s;
        }
        .mobile-nav-link:hover { color: var(--gold, #c9a84c); }
        .mobile-nav-section {
          font-family: var(--font-inter);
          font-size: 0.62rem;
          letter-spacing: 0.2em;
          text-transform: uppercase;
          color: var(--gold, #c9a84c);
          padding-top: 1.5rem;
          padding-bottom: 0.25rem;
        }
        .mobile-nav-sub {
          padding-left: 1rem;
          font-size: 0.75rem;
          color: rgba(255,255,255,0.55);
        }
      `}</style>
    </>
  );
}
