import Link from "next/link";

const footerLinks = {
  Framework: [
    { label: "Overview", href: "/framework" },
    { label: "Seven Pillars", href: "/pillars" },
    { label: "The Journey", href: "/journey" },
    { label: "Teachings", href: "/teachings" },
  ],
  Topics: [
    { label: "Anxiety", href: "/anxiety" },
    { label: "Depression", href: "/depression" },
    { label: "PTSD & Trauma", href: "/ptsd" },
    { label: "Faith & Renewal", href: "/faith" },
    { label: "Body & Nutrition", href: "/body" },
    { label: "Purpose", href: "/purpose" },
  ],
  Content: [
    { label: "Articles", href: "/articles" },
    { label: "Devotionals", href: "/devotionals" },
    { label: "Podcast", href: "/podcast" },
    { label: "Video Series", href: "/videos" },
    { label: "Resources", href: "/resources" },
  ],
  Connect: [
    { label: "About Dr. Wilson", href: "/about" },
    { label: "Speaking", href: "/speaking" },
    { label: "Membership", href: "/membership" },
    { label: "Course", href: "/course" },
    { label: "Contact", href: "/contact" },
  ],
};

export function SiteFooter() {
  return (
    <footer>
      {/* Main footer */}
      <div style={{ background: "var(--navy)" }}>
        <div className="container-site py-16">
          <div className="grid grid-cols-2 md:grid-cols-5 gap-8">

            {/* Brand column */}
            <div className="col-span-2 md:col-span-1">
              <p className="font-display text-gold tracking-widest text-sm mb-1">
                SILENCE THE NOISE<sup className="text-xs">™</sup>
              </p>
              <p className="text-xs tracking-wider mt-1" style={{ color: "rgba(255,255,255,0.3)", fontFamily: "var(--font-inter)" }}>
                Dr. Samuel E. Wilson, MD
              </p>
              <div className="mt-4 w-8 h-px" style={{ background: "var(--gold)" }} />
              <p className="mt-4 text-xs leading-relaxed" style={{ color: "rgba(255,255,255,0.35)", fontFamily: "var(--font-cormorant)", fontStyle: "italic", fontSize: "0.9rem" }}>
                One system. One journey.<br/>One framework. One message.
              </p>
              {/* Social */}
              <div className="flex gap-3 mt-5">
                {[
                  { label: "Instagram", href: "https://instagram.com/samuelewilsonmd", icon: "◉" },
                  { label: "LinkedIn", href: "https://linkedin.com/in/samuelewilsonmd", icon: "in" },
                ].map((s) => (
                  <a
                    key={s.label}
                    href={s.href}
                    target="_blank"
                    rel="noopener noreferrer"
                    aria-label={s.label}
                    className="w-8 h-8 flex items-center justify-center text-xs"
                    style={{ border: "1px solid rgba(255,255,255,0.1)", borderRadius: "2px", color: "rgba(255,255,255,0.4)", transition: "border-color 0.2s, color 0.2s" }}
                    onMouseEnter={(e) => { e.currentTarget.style.borderColor = "var(--gold)"; e.currentTarget.style.color = "var(--gold)"; }}
                    onMouseLeave={(e) => { e.currentTarget.style.borderColor = "rgba(255,255,255,0.1)"; e.currentTarget.style.color = "rgba(255,255,255,0.4)"; }}
                  >
                    {s.icon}
                  </a>
                ))}
              </div>
            </div>

            {/* Link columns */}
            {Object.entries(footerLinks).map(([group, links]) => (
              <div key={group}>
                <p className="footer-col-title">{group}</p>
                <ul className="space-y-2 list-none">
                  {links.map((link) => (
                    <li key={link.href}>
                      <Link href={link.href} className="footer-link">{link.label}</Link>
                    </li>
                  ))}
                </ul>
              </div>
            ))}
          </div>
        </div>
      </div>

      {/* Bottom bar */}
      <div style={{ background: "#06101d", padding: "1.25rem 0" }}>
        <div className="container-site flex flex-wrap items-center justify-between gap-3">
          <p className="footer-micro">
            © {new Date().getFullYear()} Samuel E. Wilson, MD · Silence the Noise™
          </p>
          <div className="flex gap-4">
            {[
              { label: "Privacy Policy", href: "/privacy" },
              { label: "Terms of Service", href: "/terms" },
              { label: "Accessibility", href: "/accessibility" },
            ].map((l) => (
              <Link key={l.href} href={l.href} className="footer-micro" style={{ color: "rgba(201,168,76,0.4)" }}>
                {l.label}
              </Link>
            ))}
          </div>
        </div>
      </div>

      <style jsx>{`
        .footer-col-title {
          font-family: var(--font-inter);
          font-size: 0.62rem;
          letter-spacing: 0.18em;
          text-transform: uppercase;
          color: var(--gold, #c9a84c);
          margin-bottom: 1rem;
          opacity: 0.8;
        }
        .footer-link {
          font-size: 0.82rem;
          color: rgba(255,255,255,0.4);
          font-family: var(--font-inter);
          transition: color 0.2s;
          display: block;
          padding: 0.1rem 0;
        }
        .footer-link:hover { color: rgba(255,255,255,0.8); }
        .footer-micro {
          font-family: var(--font-inter);
          font-size: 0.7rem;
          color: rgba(255,255,255,0.2);
        }
      `}</style>
    </footer>
  );
}
