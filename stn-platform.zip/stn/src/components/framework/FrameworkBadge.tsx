import Link from "next/link";
import { PILLARS, TOPICS, type Pillar, type TopicCategory } from "@/types";

// ── Framework Badge ────────────────────────────────────────────
// Appears on every article, devotional, podcast episode, and video
// "Part of the Silence the Noise™ Framework"

interface FrameworkBadgeProps {
  pillars?: Pillar[];
  category?: TopicCategory;
  variant?: "light" | "dark";
  className?: string;
}

export function FrameworkBadge({
  pillars = [],
  category,
  variant = "light",
  className = "",
}: FrameworkBadgeProps) {
  const isDark = variant === "dark";

  return (
    <div className={`flex flex-wrap items-center gap-2 ${className}`}>
      {/* Main STN badge */}
      <Link href="/framework" className="stn-badge" aria-label="Part of the Silence the Noise™ Framework">
        Part of Silence the Noise™
      </Link>

      {/* Pillar badges */}
      {pillars.map((pillar) => {
        const p = PILLARS[pillar];
        return (
          <Link
            key={pillar}
            href={`/journey#${pillar}`}
            className="pillar-badge"
            style={{
              background: isDark ? "rgba(255,255,255,0.05)" : "rgba(15,30,53,0.05)",
              color: isDark ? "rgba(255,255,255,0.6)" : "var(--muted)",
              border: `1px solid ${isDark ? "rgba(255,255,255,0.1)" : "var(--border)"}`,
            }}
            aria-label={`Pillar ${p.number}: ${p.title}`}
          >
            Pillar {p.number}: {p.title}
          </Link>
        );
      })}

      {/* Category badge */}
      {category && (
        <Link
          href={`/${category}`}
          className="pillar-badge"
          style={{
            background: "rgba(201,168,76,0.08)",
            color: "var(--gold)",
            border: "1px solid rgba(201,168,76,0.2)",
          }}
        >
          {TOPICS[category].icon} {TOPICS[category].title}
        </Link>
      )}

      <style jsx>{`
        .pillar-badge {
          font-family: var(--font-inter);
          font-size: 0.62rem;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          padding: 0.2rem 0.6rem;
          border-radius: 2px;
          font-weight: 500;
          transition: opacity 0.2s;
        }
        .pillar-badge:hover { opacity: 0.75; }
      `}</style>
    </div>
  );
}

// ── Pillar Progress Bar ────────────────────────────────────────
// Shows which pillars are covered in the current content
interface PillarProgressProps {
  activePillars: Pillar[];
}

export function PillarProgress({ activePillars }: PillarProgressProps) {
  return (
    <div className="pillar-progress" role="list" aria-label="Framework pillars in this content">
      {(Object.keys(PILLARS) as Pillar[]).map((pillar) => {
        const p = PILLARS[pillar];
        const isActive = activePillars.includes(pillar);
        return (
          <Link
            key={pillar}
            href={`/journey#${pillar}`}
            className="pillar-step"
            style={{ opacity: isActive ? 1 : 0.3 }}
            role="listitem"
            aria-label={`${p.title} ${isActive ? "(covered in this content)" : ""}`}
          >
            <div className="pillar-step-dot" style={{ background: isActive ? "var(--gold)" : "var(--border)" }} />
            <span className="pillar-step-label">{p.title}</span>
          </Link>
        );
      })}
      <style jsx>{`
        .pillar-progress {
          display: flex; flex-wrap: wrap; gap: 0.75rem; align-items: center;
        }
        .pillar-step {
          display: flex; align-items: center; gap: 0.35rem;
          transition: opacity 0.2s;
        }
        .pillar-step:hover { opacity: 0.75 !important; }
        .pillar-step-dot {
          width: 7px; height: 7px; border-radius: 50%;
        }
        .pillar-step-label {
          font-family: var(--font-inter);
          font-size: 0.65rem;
          letter-spacing: 0.1em;
          text-transform: uppercase;
          color: var(--muted);
        }
      `}</style>
    </div>
  );
}

// ── Related Content Block ──────────────────────────────────────
// Appears at the bottom of every article and devotional

interface RelatedItem {
  _id: string;
  title: string;
  slug: { current: string };
  excerpt?: string;
  readingTime?: number;
  category?: TopicCategory;
  pillars?: Pillar[];
}

interface RelatedContentProps {
  items: RelatedItem[];
  type?: "article" | "devotional";
  heading?: string;
}

export function RelatedContent({
  items,
  type = "article",
  heading = "Continue the Journey",
}: RelatedContentProps) {
  if (!items.length) return null;
  const basePath = type === "article" ? "/articles" : "/devotionals";

  return (
    <section className="related-section">
      <div className="flex items-center gap-3 mb-5">
        <div className="gold-rule" style={{ margin: 0 }} />
        <p className="label-text" style={{ margin: 0 }}>{heading}</p>
      </div>
      <div className="related-grid">
        {items.map((item) => (
          <Link key={item._id} href={`${basePath}/${item.slug.current}`} className="related-card">
            {item.category && (
              <span className="related-cat">{TOPICS[item.category]?.icon} {TOPICS[item.category]?.title}</span>
            )}
            <h4>{item.title}</h4>
            {item.excerpt && <p>{item.excerpt}</p>}
            {item.readingTime && <span className="related-meta">{item.readingTime} min read →</span>}
          </Link>
        ))}
      </div>
      <style jsx>{`
        .related-section { margin-top: 4rem; padding-top: 3rem; border-top: 1px solid var(--border); }
        .related-grid { display: grid; grid-template-columns: repeat(auto-fill, minmax(260px, 1fr)); gap: 1rem; }
        .related-card {
          padding: 1.5rem; border: 1px solid var(--border); border-radius: 2px;
          transition: border-color 0.2s, box-shadow 0.2s; display: block;
        }
        .related-card:hover { border-color: var(--gold); box-shadow: 0 4px 20px rgba(15,30,53,0.08); }
        .related-cat {
          font-family: var(--font-inter); font-size: 0.62rem;
          letter-spacing: 0.12em; text-transform: uppercase; color: var(--gold);
          display: block; margin-bottom: 0.5rem;
        }
        .related-card h4 {
          font-family: var(--font-cormorant); font-size: 1.1rem;
          font-weight: 600; color: var(--navy); margin-bottom: 0.4rem;
        }
        .related-card p {
          font-family: var(--font-cormorant); font-size: 0.92rem;
          color: var(--muted); line-height: 1.6; font-style: italic;
          margin-bottom: 0.75rem;
        }
        .related-meta {
          font-family: var(--font-inter); font-size: 0.68rem;
          letter-spacing: 0.1em; text-transform: uppercase; color: var(--gold);
        }
      `}</style>
    </section>
  );
}
