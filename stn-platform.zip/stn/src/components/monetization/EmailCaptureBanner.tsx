export { EmailCaptureBanner } from "./index";
