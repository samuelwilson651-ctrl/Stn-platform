"use client";

import { useState } from "react";
import Link from "next/link";
import { PRODUCTS, formatCurrency, type ProductType } from "@/types";

// ── Pricing Table ──────────────────────────────────────────────
export function PricingTable() {
  const [billing, setBilling] = useState<"monthly" | "annual">("monthly");

  const products: ProductType[] = billing === "monthly"
    ? ["membership_monthly", "course_stn", "consultation"]
    : ["membership_annual", "course_stn", "consultation"];

  return (
    <div className="pricing-wrap">
      {/* Billing toggle */}
      <div className="billing-toggle" role="group" aria-label="Billing period">
        <button
          className={`toggle-btn ${billing === "monthly" ? "active" : ""}`}
          onClick={() => setBilling("monthly")}
          aria-pressed={billing === "monthly"}
        >Monthly</button>
        <button
          className={`toggle-btn ${billing === "annual" ? "active" : ""}`}
          onClick={() => setBilling("annual")}
          aria-pressed={billing === "annual"}
        >
          Annual <span className="save-badge">Save 35%</span>
        </button>
      </div>

      <div className="pricing-grid">
        {products.map((id) => {
          const product = PRODUCTS[id];
          return (
            <div key={id} className={`pricing-card ${product.featured ? "featured" : ""}`}>
              {product.tag && <div className="pricing-tag">{product.tag}</div>}
              <div className="pricing-name">{product.name}</div>
              <div className="pricing-price">
                <span className="price-amount">{formatCurrency(product.price)}</span>
                {product.interval && (
                  <span className="price-interval"> / {product.interval}</span>
                )}
              </div>
              <p className="pricing-desc">{product.description}</p>
              <ul className="pricing-features" role="list">
                {product.features.map((f, i) => (
                  <li key={i} className="pricing-feature">
                    <span className="feature-check">✓</span> {f}
                  </li>
                ))}
              </ul>
              <CheckoutButton productType={id} className={product.featured ? "btn btn-gold w-full justify-center" : "btn btn-outline-dark w-full justify-center"} />
            </div>
          );
        })}
      </div>

      <style jsx>{`
        .pricing-wrap { max-width: 1000px; margin: 0 auto; }
        .billing-toggle {
          display: flex; justify-content: center; gap: 0; margin-bottom: 3rem;
          border: 1px solid var(--border); border-radius: 3px; overflow: hidden;
          width: fit-content; margin: 0 auto 3rem;
        }
        .toggle-btn {
          font-family: var(--font-inter); font-size: 0.72rem; letter-spacing: 0.1em;
          text-transform: uppercase; font-weight: 500;
          padding: 0.6rem 1.5rem; border: none; cursor: pointer;
          background: white; color: var(--muted); transition: all 0.2s;
          display: flex; align-items: center; gap: 0.5rem;
        }
        .toggle-btn.active { background: var(--navy); color: white; }
        .save-badge {
          font-size: 0.55rem; background: var(--gold);
          color: var(--navy); padding: 0.1rem 0.4rem; border-radius: 2px; font-weight: 700;
        }
        .pricing-grid {
          display: grid; grid-template-columns: repeat(auto-fit, minmax(280px, 1fr)); gap: 1.5rem;
        }
        .pricing-card {
          background: white; border: 1px solid var(--border); border-radius: 2px;
          padding: 2rem; position: relative; display: flex; flex-direction: column; gap: 0.75rem;
        }
        .pricing-card.featured {
          border-color: var(--gold); box-shadow: 0 8px 40px rgba(201,168,76,0.12);
        }
        .pricing-tag {
          position: absolute; top: -1px; right: 1.5rem;
          background: var(--gold); color: var(--navy);
          font-family: var(--font-inter); font-size: 0.6rem; letter-spacing: 0.12em;
          text-transform: uppercase; font-weight: 700;
          padding: 0.2rem 0.6rem; border-radius: 0 0 3px 3px;
        }
        .pricing-name {
          font-family: var(--font-cormorant); font-size: 1.3rem;
          font-weight: 600; color: var(--navy);
        }
        .pricing-price { display: flex; align-items: baseline; gap: 0.1rem; }
        .price-amount {
          font-family: var(--font-cinzel); font-size: 2.25rem;
          color: var(--navy); letter-spacing: 0.03em;
        }
        .price-interval {
          font-family: var(--font-inter); font-size: 0.78rem;
          color: var(--muted); letter-spacing: 0.08em;
        }
        .pricing-desc {
          font-family: var(--font-cormorant); font-size: 0.95rem;
          color: var(--muted); font-style: italic; line-height: 1.6;
        }
        .pricing-features { list-style: none; display: flex; flex-direction: column; gap: 0.5rem; margin: 0.5rem 0; }
        .pricing-feature {
          font-family: var(--font-inter); font-size: 0.82rem; color: var(--navy);
          display: flex; align-items: flex-start; gap: 0.5rem; line-height: 1.5;
        }
        .feature-check { color: var(--gold); font-weight: 700; flex-shrink: 0; }
        .w-full { width: 100%; }
        .justify-center { justify-content: center; }
      `}</style>
    </div>
  );
}

// ── Checkout Button ────────────────────────────────────────────
interface CheckoutButtonProps {
  productType: ProductType;
  className?: string;
  children?: React.ReactNode;
}

export function CheckoutButton({ productType, className = "btn btn-gold", children }: CheckoutButtonProps) {
  const [loading, setLoading] = useState(false);

  const handleCheckout = async () => {
    setLoading(true);
    try {
      const res = await fetch("/api/stripe/checkout", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({
          productType,
          successUrl: `${window.location.origin}/dashboard?success=true`,
          cancelUrl: window.location.href,
        }),
      });
      const data = await res.json();
      if (data.url) window.location.href = data.url;
      else throw new Error("No checkout URL returned");
    } catch (err) {
      console.error("Checkout error:", err);
      alert("Something went wrong. Please try again or contact us.");
    } finally {
      setLoading(false);
    }
  };

  return (
    <button className={className} onClick={handleCheckout} disabled={loading}>
      {loading ? "Redirecting…" : (children ?? "Get Started")}
    </button>
  );
}

// ── Member Gate ────────────────────────────────────────────────
// Wraps member-only content with blur + CTA

interface MemberGateProps {
  children: React.ReactNode;
  preview?: React.ReactNode; // First ~30% to show before gate
  title?: string;
}

export function MemberGate({ children, preview, title }: MemberGateProps) {
  return (
    <div className="gate-wrap">
      {preview && (
        <div className="gate-preview">
          {preview}
          <div className="gate-fade" />
        </div>
      )}
      <div className="gate-cta">
        <div className="gate-cta-inner">
          <p className="label-text" style={{ textAlign: "center" }}>Member Content</p>
          <h3>{title ?? "Continue Reading"}</h3>
          <p>This content is part of the Silence the Noise™ member library. Join to access the full article, plus 50+ devotionals, podcast episodes, videos, and community.</p>
          <div className="gate-actions">
            <Link href="/membership" className="btn btn-gold">Join the Community</Link>
            <Link href="/login" className="btn btn-outline-dark">Sign In</Link>
          </div>
          <p className="gate-guarantee">30-day satisfaction guarantee · Cancel anytime</p>
        </div>
      </div>
      <style jsx>{`
        .gate-wrap { position: relative; }
        .gate-preview { position: relative; max-height: 320px; overflow: hidden; }
        .gate-fade {
          position: absolute; bottom: 0; left: 0; width: 100%; height: 160px;
          background: linear-gradient(to bottom, transparent, var(--cream));
          pointer-events: none;
        }
        .gate-cta {
          background: white; border: 1px solid var(--border); border-radius: 3px;
          padding: 3rem 2rem; text-align: center;
          box-shadow: 0 4px 24px rgba(15,30,53,0.06);
        }
        .gate-cta-inner { max-width: 480px; margin: 0 auto; }
        .gate-cta h3 {
          font-family: var(--font-cormorant); font-size: 1.75rem; font-weight: 600;
          color: var(--navy); margin-bottom: 0.75rem;
        }
        .gate-cta p {
          font-family: var(--font-cormorant); font-size: 1.05rem; color: var(--muted);
          line-height: 1.75; font-style: italic; margin-bottom: 1.5rem;
        }
        .gate-actions { display: flex; gap: 0.75rem; justify-content: center; flex-wrap: wrap; }
        .gate-guarantee {
          font-family: var(--font-inter); font-size: 0.68rem; letter-spacing: 0.1em;
          color: var(--muted); margin-top: 1rem; font-style: normal !important;
        }
      `}</style>
    </div>
  );
}

// ── Email Capture Banner ───────────────────────────────────────
// Sticky bottom banner for newsletter signup

export function EmailCaptureBanner() {
  const [dismissed, setDismissed] = useState(false);
  const [email, setEmail] = useState("");
  const [submitted, setSubmitted] = useState(false);
  const [loading, setLoading] = useState(false);

  if (dismissed || submitted) return null;

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setLoading(true);
    try {
      await fetch("/api/email/subscribe", {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ email, source: "banner" }),
      });
      setSubmitted(true);
    } catch {
      // fail silently on banner
    } finally {
      setLoading(false);
    }
  };

  return (
    <div className="email-banner" role="complementary" aria-label="Newsletter signup">
      <div className="email-banner-inner">
        <div className="email-banner-text">
          <p className="email-banner-title">Start with one reflection.</p>
          <p className="email-banner-sub">Weekly wisdom from Dr. Wilson — free, physician-led, faith-centered.</p>
        </div>
        <form onSubmit={handleSubmit} className="email-banner-form" role="form">
          <input
            type="email"
            value={email}
            onChange={(e) => setEmail(e.target.value)}
            placeholder="your@email.com"
            required
            aria-label="Email address"
            className="email-input"
          />
          <button type="submit" disabled={loading} className="btn btn-gold" style={{ whiteSpace: "nowrap" }}>
            {loading ? "…" : "Get Free Reflections"}
          </button>
        </form>
        <button
          onClick={() => setDismissed(true)}
          className="email-dismiss"
          aria-label="Dismiss newsletter banner"
        >✕</button>
      </div>
      <style jsx>{`
        .email-banner {
          position: fixed; bottom: 0; left: 0; right: 0; z-index: 30;
          background: var(--navy); border-top: 1px solid rgba(201,168,76,0.2);
          padding: 1rem 2rem;
        }
        .email-banner-inner {
          max-width: 900px; margin: 0 auto;
          display: flex; align-items: center; gap: 2rem; flex-wrap: wrap;
        }
        .email-banner-text { flex: 1; min-width: 200px; }
        .email-banner-title {
          font-family: var(--font-cormorant); font-size: 1.05rem;
          font-weight: 600; color: white; margin: 0;
        }
        .email-banner-sub {
          font-family: var(--font-inter); font-size: 0.72rem;
          color: rgba(255,255,255,0.45); margin: 0.1rem 0 0;
        }
        .email-banner-form { display: flex; gap: 0.5rem; flex-wrap: wrap; }
        .email-input {
          padding: 0.7rem 1rem; border: 1px solid rgba(201,168,76,0.25);
          border-radius: 2px; background: rgba(255,255,255,0.05);
          color: white; font-family: var(--font-inter); font-size: 0.82rem;
          outline: none; width: 220px;
        }
        .email-input::placeholder { color: rgba(255,255,255,0.3); }
        .email-input:focus { border-color: var(--gold); }
        .email-dismiss {
          background: none; border: none; cursor: pointer;
          color: rgba(255,255,255,0.3); font-size: 1rem;
          transition: color 0.2s; flex-shrink: 0;
        }
        .email-dismiss:hover { color: white; }
        @media (max-width: 600px) {
          .email-banner { padding: 1rem; }
          .email-banner-inner { gap: 1rem; }
          .email-input { width: 100%; }
        }
      `}</style>
    </div>
  );
}

// ── Journey CTA ────────────────────────────────────────────────
// Re-usable CTA section used throughout the site

interface JourneyCTAProps {
  variant?: "dark" | "light";
  heading?: string;
  subheading?: string;
}

export function JourneyCTA({
  variant = "dark",
  heading = "Silence the Noise™",
  subheading = "One system. One journey. One framework. One message.",
}: JourneyCTAProps) {
  const isDark = variant === "dark";
  return (
    <section
      className="journey-cta-section"
      style={{ background: isDark ? "var(--navy)" : "var(--cream-dark)", padding: "6rem 2rem", textAlign: "center" }}
    >
      <h2 style={{ fontFamily: "var(--font-cinzel)", fontSize: "clamp(2.5rem, 6vw, 5rem)", fontWeight: 400, color: isDark ? "white" : "var(--navy)", letterSpacing: "0.07em", marginBottom: "0.5rem" }}>
        {heading}<sup style={{ fontSize: "0.3em", color: "var(--gold)", verticalAlign: "super" }}>™</sup>
      </h2>
      <p style={{ fontFamily: "var(--font-cormorant)", fontStyle: "italic", fontSize: "1.1rem", color: isDark ? "rgba(255,255,255,0.4)" : "var(--muted)", marginBottom: "2.5rem" }}>
        {subheading}
      </p>
      <div style={{ display: "flex", gap: "1rem", justifyContent: "center", flexWrap: "wrap" }}>
        <Link href="/journey" className="btn btn-gold">Start the Journey →</Link>
        <Link href="/membership" className={`btn ${isDark ? "btn-outline-light" : "btn-outline-dark"}`}>Join the Community</Link>
      </div>
    </section>
  );
}
