import { Resend } from "resend";
import type { EmailSubscriber } from "@/types";

export const resend = new Resend(process.env.RESEND_API_KEY);

const FROM = `${process.env.RESEND_FROM_NAME} <${process.env.RESEND_FROM_EMAIL}>`;
const REPLY_TO = process.env.RESEND_REPLY_TO;

// ── Newsletter subscribe ───────────────────────────────────────
export async function subscribeToNewsletter(subscriber: EmailSubscriber) {
  // Add to Resend audience
  await resend.contacts.create({
    email: subscriber.email,
    firstName: subscriber.firstName,
    audienceId: process.env.RESEND_AUDIENCE_NEWSLETTER!,
  });

  // Send welcome email
  await resend.emails.send({
    from: FROM,
    to: subscriber.email,
    replyTo: REPLY_TO,
    subject: "You're in — welcome to Silence the Noise™",
    html: welcomeEmailHtml(subscriber.firstName),
  });
}

// ── Post-checkout ──────────────────────────────────────────────
export async function sendMembershipWelcome(email: string, firstName: string, plan: string) {
  await resend.emails.send({
    from: FROM,
    to: email,
    replyTo: REPLY_TO,
    subject: "Your membership is active — welcome to the community",
    html: membershipWelcomeHtml(firstName, plan),
  });
}

export async function sendCourseAccessEmail(email: string, firstName: string) {
  await resend.emails.send({
    from: FROM,
    to: email,
    replyTo: REPLY_TO,
    subject: "Your Silence the Noise™ Course access is ready",
    html: courseAccessHtml(firstName),
  });
}

export async function sendConsultationConfirmation(email: string, firstName: string) {
  await resend.emails.send({
    from: FROM,
    to: email,
    replyTo: REPLY_TO,
    subject: "Your consultation with Dr. Wilson — next steps",
    html: consultationConfirmHtml(firstName),
  });
}

// ── Speaking inquiry ───────────────────────────────────────────
export async function sendSpeakingInquiryNotification(data: {
  name: string;
  email: string;
  organization: string;
  eventDate?: string;
  message: string;
}) {
  // Notify Dr. Wilson
  await resend.emails.send({
    from: FROM,
    to: process.env.RESEND_FROM_EMAIL!,
    subject: `Speaking Inquiry — ${data.organization}`,
    html: `
      <h2>New Speaking Inquiry</h2>
      <p><strong>Name:</strong> ${data.name}</p>
      <p><strong>Email:</strong> ${data.email}</p>
      <p><strong>Organization:</strong> ${data.organization}</p>
      ${data.eventDate ? `<p><strong>Event Date:</strong> ${data.eventDate}</p>` : ""}
      <p><strong>Message:</strong></p>
      <p>${data.message}</p>
    `,
  });

  // Confirm to inquirer
  await resend.emails.send({
    from: FROM,
    to: data.email,
    replyTo: REPLY_TO,
    subject: "We received your speaking inquiry",
    html: speakingConfirmHtml(data.name),
  });
}

// ── Email templates ────────────────────────────────────────────
// These are inline HTML — replace with @react-email components for production

function emailWrapper(content: string) {
  return `
<!DOCTYPE html>
<html>
<head>
  <meta charset="utf-8"/>
  <meta name="viewport" content="width=device-width"/>
  <style>
    body { font-family: Georgia, serif; background: #faf7f2; margin: 0; padding: 0; }
    .wrap { max-width: 600px; margin: 0 auto; background: #ffffff; }
    .header { background: #0f1e35; padding: 2.5rem 2rem; text-align: center; }
    .header h1 { color: #c9a84c; font-size: 1.4rem; letter-spacing: 0.1em; margin: 0; }
    .header p { color: rgba(255,255,255,0.5); font-size: 0.8rem; margin: 0.4rem 0 0; font-style: italic; }
    .body { padding: 2.5rem 2rem; }
    .body p { color: #3d3530; line-height: 1.85; font-size: 1rem; margin: 0 0 1rem; }
    .body h2 { color: #0f1e35; font-size: 1.4rem; margin: 0 0 1rem; }
    .cta { display: block; background: #c9a84c; color: #0f1e35; text-align: center; 
           padding: 0.9rem 2rem; text-decoration: none; font-family: sans-serif;
           font-size: 0.8rem; letter-spacing: 0.1em; text-transform: uppercase;
           font-weight: 700; margin: 2rem 0; }
    .rule { width: 44px; height: 2px; background: #c9a84c; margin: 1.5rem 0; }
    .quote { border-left: 3px solid #c9a84c; padding-left: 1.25rem; color: #0f1e35;
             font-style: italic; font-size: 1.05rem; line-height: 1.7; margin: 1.5rem 0; }
    .footer { background: #0f1e35; padding: 1.5rem 2rem; text-align: center; }
    .footer p { color: rgba(255,255,255,0.3); font-size: 0.7rem; font-family: sans-serif; margin: 0; }
    .footer a { color: rgba(201,168,76,0.6); }
  </style>
</head>
<body>
<div class="wrap">
  <div class="header">
    <h1>SILENCE THE NOISE™</h1>
    <p>Dr. Samuel E. Wilson, MD</p>
  </div>
  <div class="body">${content}</div>
  <div class="footer">
    <p>© 2026 Samuel E. Wilson, MD · <a href="https://samuelewilson.org">samuelewilson.org</a><br/>
    <a href="https://samuelewilson.org/unsubscribe">Unsubscribe</a> · 
    <a href="https://samuelewilson.org/privacy">Privacy Policy</a></p>
  </div>
</div>
</body>
</html>`;
}

function welcomeEmailHtml(firstName?: string) {
  return emailWrapper(`
    <h2>Welcome${firstName ? `, ${firstName}` : ""}.</h2>
    <div class="rule"></div>
    <p>You've joined a growing community of people committed to one thing: silencing the noise.</p>
    <div class="quote">
      "Many people do not simply need more information. They need less noise."
    </div>
    <p>Over the next few days, you'll receive your first free reflections — physician-led, 
       faith-rooted, and practical. Each one is designed to give you one clear thing 
       to think about and one clear thing to do.</p>
    <p>In the meantime, you can explore the full framework:</p>
    <a href="https://samuelewilson.org/framework" class="cta">Explore the Framework →</a>
    <p>If you have questions, simply reply to this email. Every message is read.</p>
    <p>— Dr. Samuel E. Wilson, MD</p>
  `);
}

function membershipWelcomeHtml(firstName: string, plan: string) {
  return emailWrapper(`
    <h2>Welcome to the community, ${firstName}.</h2>
    <div class="rule"></div>
    <p>Your ${plan} membership is now active. You have full access to the 
       Silence the Noise™ member library — articles, devotionals, podcast, video series, 
       and community discussion.</p>
    <a href="https://samuelewilson.org/dashboard" class="cta">Access Your Dashboard →</a>
    <p>Your membership includes monthly live Q&A sessions with Dr. Wilson. 
       Watch your inbox — the next session date will be announced shortly.</p>
    <p>— Dr. Samuel E. Wilson, MD</p>
  `);
}

function courseAccessHtml(firstName: string) {
  return emailWrapper(`
    <h2>Your course is ready, ${firstName}.</h2>
    <div class="rule"></div>
    <p>The Silence the Noise™ Course is now unlocked in your dashboard. 
       Start with Module 1: Awareness — it will take approximately 45 minutes 
       and includes a downloadable workbook.</p>
    <a href="https://samuelewilson.org/course" class="cta">Start Module 1 →</a>
    <p>Take your time. This course is designed to be lived, not consumed.</p>
    <p>— Dr. Samuel E. Wilson, MD</p>
  `);
}

function consultationConfirmHtml(firstName: string) {
  return emailWrapper(`
    <h2>Your consultation is confirmed, ${firstName}.</h2>
    <div class="rule"></div>
    <p>Dr. Wilson will reach out within 2 business days to schedule your session. 
       Please watch for an email from this address with available times.</p>
    <p>To prepare, please complete your intake questionnaire when you receive it. 
       This helps Dr. Wilson make the most of your time together.</p>
    <a href="https://samuelewilson.org/dashboard" class="cta">View Dashboard →</a>
    <p>— The Silence the Noise™ Team</p>
  `);
}

function speakingConfirmHtml(name: string) {
  return emailWrapper(`
    <h2>Thank you, ${name}.</h2>
    <div class="rule"></div>
    <p>We received your speaking inquiry and will respond within 3–5 business days.</p>
    <p>In the meantime, you can explore Dr. Wilson's keynote topics and past speaking engagements 
       on the website.</p>
    <a href="https://samuelewilson.org/speaking" class="cta">View Speaking Topics →</a>
    <p>— The Silence the Noise™ Team</p>
  `);
}
