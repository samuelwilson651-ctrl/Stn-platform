"use client";

// ── Vercel Analytics (server auto-injected) ────────────────────
// Install @vercel/analytics and add <Analytics /> to layout.tsx

// ── Google Analytics 4 ────────────────────────────────────────
declare global {
  interface Window { gtag?: (...args: unknown[]) => void; dataLayer?: unknown[]; }
}

export function trackEvent(name: string, params?: Record<string, string | number | boolean>) {
  if (typeof window === "undefined") return;
  if (window.gtag) {
    window.gtag("event", name, params);
  }
}

// ── Framework-specific events ──────────────────────────────────
export const events = {
  journeyStarted: () => trackEvent("journey_started"),
  pillarViewed: (pillar: string) => trackEvent("pillar_viewed", { pillar }),
  articleRead: (slug: string, category: string) => trackEvent("article_read", { slug, category }),
  devotionalOpened: (slug: string, theme: string) => trackEvent("devotional_opened", { slug, theme }),
  podcastPlayed: (episode: string) => trackEvent("podcast_played", { episode }),
  checkoutStarted: (product: string, price: number) => trackEvent("checkout_started", { product, price }),
  memberSignup: (plan: string) => trackEvent("member_signup", { plan }),
  newsletterSignup: (source: string) => trackEvent("newsletter_signup", { source }),
  speakingInquiry: () => trackEvent("speaking_inquiry"),
  resourceDownloaded: (resource: string) => trackEvent("resource_downloaded", { resource }),
  contentGated: (slug: string) => trackEvent("content_gated", { slug }),
};
