import Stripe from "stripe";
import { PRODUCTS, type ProductType } from "@/types";

// ── Client ─────────────────────────────────────────────────────
export const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, {
  apiVersion: "2024-04-10",
  typescript: true,
});

// ── Price ID helpers ───────────────────────────────────────────
export function getStripePriceId(productType: ProductType): string {
  const envMap: Record<ProductType, string> = {
    membership_monthly: process.env.STRIPE_PRICE_MEMBERSHIP_MONTHLY!,
    membership_annual:  process.env.STRIPE_PRICE_MEMBERSHIP_ANNUAL!,
    course_stn:         process.env.STRIPE_PRICE_COURSE_STN!,
    coaching_session:   process.env.STRIPE_PRICE_COACHING_SESSION!,
    consultation:       process.env.STRIPE_PRICE_CONSULTATION!,
  };
  const priceId = envMap[productType];
  if (!priceId) throw new Error(`Missing Stripe price ID for: ${productType}`);
  return priceId;
}

// ── Checkout Session ───────────────────────────────────────────
export interface CreateCheckoutParams {
  productType: ProductType;
  userId: string;
  userEmail: string;
  stripeCustomerId?: string;
  successUrl: string;
  cancelUrl: string;
  trialDays?: number;
}

export async function createCheckoutSession(params: CreateCheckoutParams) {
  const { productType, userId, userEmail, stripeCustomerId, successUrl, cancelUrl, trialDays } = params;
  const product = PRODUCTS[productType];
  const priceId = getStripePriceId(productType);
  const isSubscription = !!product.interval;

  const sessionParams: Stripe.Checkout.SessionCreateParams = {
    mode: isSubscription ? "subscription" : "payment",
    customer: stripeCustomerId,
    customer_email: stripeCustomerId ? undefined : userEmail,
    line_items: [{ price: priceId, quantity: 1 }],
    success_url: `${successUrl}?session_id={CHECKOUT_SESSION_ID}`,
    cancel_url: cancelUrl,
    metadata: { userId, productType },
    allow_promotion_codes: true,
  };

  if (isSubscription && trialDays) {
    sessionParams.subscription_data = {
      trial_period_days: trialDays,
      metadata: { userId, productType },
    };
  }

  if (!isSubscription) {
    sessionParams.payment_intent_data = { metadata: { userId, productType } };
  }

  return stripe.checkout.sessions.create(sessionParams);
}

// ── Customer Portal ────────────────────────────────────────────
export async function createPortalSession(stripeCustomerId: string, returnUrl: string) {
  return stripe.billingPortal.sessions.create({
    customer: stripeCustomerId,
    return_url: returnUrl,
  });
}

// ── Customer ───────────────────────────────────────────────────
export async function createOrRetrieveCustomer(email: string, name?: string) {
  const existing = await stripe.customers.list({ email, limit: 1 });
  if (existing.data.length > 0) return existing.data[0];
  return stripe.customers.create({ email, name, metadata: { source: "silence-the-noise" } });
}

// ── Subscription checks ────────────────────────────────────────
export async function getActiveSubscription(stripeCustomerId: string) {
  const subs = await stripe.subscriptions.list({
    customer: stripeCustomerId,
    status: "active",
    limit: 1,
  });
  return subs.data[0] ?? null;
}

export async function hasActiveMembership(stripeCustomerId?: string): Promise<boolean> {
  if (!stripeCustomerId) return false;
  const sub = await getActiveSubscription(stripeCustomerId);
  return !!sub;
}

// ── Webhook verification ───────────────────────────────────────
export function constructWebhookEvent(payload: Buffer, signature: string) {
  return stripe.webhooks.constructEvent(
    payload,
    signature,
    process.env.STRIPE_WEBHOOK_SECRET!
  );
}

// ── Readable amounts ───────────────────────────────────────────
export function formatCurrency(cents: number): string {
  return new Intl.NumberFormat("en-US", {
    style: "currency",
    currency: "USD",
    minimumFractionDigits: 0,
  }).format(cents / 100);
}
