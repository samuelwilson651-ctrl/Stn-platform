import { createClient } from "@sanity/client";
import imageUrlBuilder from "@sanity/image-url";
import type { SanityImage } from "@/types";

export const sanityClient = createClient({
  projectId: process.env.NEXT_PUBLIC_SANITY_PROJECT_ID!,
  dataset: process.env.NEXT_PUBLIC_SANITY_DATASET ?? "production",
  apiVersion: process.env.NEXT_PUBLIC_SANITY_API_VERSION ?? "2024-01-01",
  useCdn: process.env.NODE_ENV === "production",
  token: process.env.SANITY_API_TOKEN,
});

const builder = imageUrlBuilder(sanityClient);

export function urlFor(source: SanityImage) {
  return builder.image(source);
}

// ── GROQ Queries ───────────────────────────────────────────────

export const queries = {
  // All published articles, newest first
  allArticles: /* groq */ `
    *[_type == "article" && defined(slug.current)] | order(publishedAt desc) {
      _id, title, slug, excerpt, category, pillars, tags,
      publishedAt, readingTime, featured, memberOnly,
      coverImage, "author": author->{ name, credentials, image }
    }
  `,

  // Articles by category
  articlesByCategory: /* groq */ `
    *[_type == "article" && category == $category && defined(slug.current)] 
    | order(publishedAt desc) {
      _id, title, slug, excerpt, category, pillars,
      publishedAt, readingTime, memberOnly, coverImage
    }
  `,

  // Single article by slug
  articleBySlug: /* groq */ `
    *[_type == "article" && slug.current == $slug][0] {
      _id, title, slug, excerpt, body, category, pillars, tags,
      publishedAt, updatedAt, readingTime, memberOnly, seo,
      coverImage, "author": author->{ name, credentials, bio, image },
      "related": *[_type == "article" && category == ^.category && slug.current != $slug] 
        | order(publishedAt desc)[0..2] { _id, title, slug, excerpt, readingTime, coverImage }
    }
  `,

  // Featured articles for homepage
  featuredArticles: /* groq */ `
    *[_type == "article" && featured == true] | order(publishedAt desc)[0..5] {
      _id, title, slug, excerpt, category, pillars, readingTime, memberOnly, coverImage
    }
  `,

  // All devotionals
  allDevotionals: /* groq */ `
    *[_type == "devotional" && defined(slug.current)] | order(publishedAt desc) {
      _id, title, slug, scriptureReference, category, pillars, theme,
      publishedAt, memberOnly, coverImage
    }
  `,

  // Single devotional by slug
  devotionalBySlug: /* groq */ `
    *[_type == "devotional" && slug.current == $slug][0] {
      _id, title, slug, scripture, scriptureReference, reflection, prayer,
      category, pillars, theme, publishedAt, memberOnly, seo, coverImage
    }
  `,

  // All podcast episodes
  allPodcast: /* groq */ `
    *[_type == "podcast"] | order(episodeNumber desc) {
      _id, title, slug, episodeNumber, description, duration,
      audioUrl, category, pillars, publishedAt, memberOnly, coverImage
    }
  `,

  // All video series
  allVideos: /* groq */ `
    *[_type == "videoSeries"] | order(seriesNumber desc) {
      _id, title, slug, seriesNumber, description, duration,
      videoUrl, category, pillars, publishedAt, memberOnly, thumbnailUrl
    }
  `,

  // Content by pillar (cross-type)
  contentByPillar: /* groq */ `
    {
      "articles": *[_type == "article" && $pillar in pillars] | order(publishedAt desc)[0..5] 
        { _id, title, slug, excerpt, category, readingTime, memberOnly },
      "devotionals": *[_type == "devotional" && $pillar in pillars] | order(publishedAt desc)[0..3]
        { _id, title, slug, scriptureReference, category, memberOnly },
      "podcast": *[_type == "podcast" && $pillar in pillars] | order(publishedAt desc)[0..2]
        { _id, title, slug, episodeNumber, duration, memberOnly }
    }
  `,

  // Sitemap — all published content
  sitemap: /* groq */ `
    {
      "articles": *[_type == "article" && defined(slug.current)] { "slug": slug.current, publishedAt },
      "devotionals": *[_type == "devotional" && defined(slug.current)] { "slug": slug.current, publishedAt },
      "podcast": *[_type == "podcast" && defined(slug.current)] { "slug": slug.current, publishedAt }
    }
  `,
};

// ── Fetch helpers ──────────────────────────────────────────────

export async function getAllArticles() {
  return sanityClient.fetch(queries.allArticles);
}

export async function getArticlesByCategory(category: string) {
  return sanityClient.fetch(queries.articlesByCategory, { category });
}

export async function getArticleBySlug(slug: string) {
  return sanityClient.fetch(queries.articleBySlug, { slug });
}

export async function getFeaturedArticles() {
  return sanityClient.fetch(queries.featuredArticles);
}

export async function getAllDevotionals() {
  return sanityClient.fetch(queries.allDevotionals);
}

export async function getDevotionalBySlug(slug: string) {
  return sanityClient.fetch(queries.devotionalBySlug, { slug });
}

export async function getAllPodcast() {
  return sanityClient.fetch(queries.allPodcast);
}

export async function getAllVideos() {
  return sanityClient.fetch(queries.allVideos);
}

export async function getContentByPillar(pillar: string) {
  return sanityClient.fetch(queries.contentByPillar, { pillar });
}
