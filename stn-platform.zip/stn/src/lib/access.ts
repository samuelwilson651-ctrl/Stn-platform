import { auth, currentUser } from "@clerk/nextjs/server";
import { redirect } from "next/navigation";
import { hasActiveMembership } from "./stripe";

// ── Server-side access checks ──────────────────────────────────

export async function requireAuth() {
  const { userId } = await auth();
  if (!userId) redirect("/login");
  return userId;
}

export async function getUserAccess(): Promise<{
  userId: string | null;
  isAuthenticated: boolean;
  isMember: boolean;
  stripeCustomerId?: string;
}> {
  const { userId } = await auth();
  if (!userId) return { userId: null, isAuthenticated: false, isMember: false };

  const user = await currentUser();
  const stripeCustomerId = user?.privateMetadata?.stripeCustomerId as string | undefined;
  const isMember = await hasActiveMembership(stripeCustomerId);

  return { userId, isAuthenticated: true, isMember, stripeCustomerId };
}

// ── Membership gate helper ─────────────────────────────────────
// Use in page.tsx server components to gate full pages
export async function requireMembership() {
  const { isAuthenticated, isMember } = await getUserAccess();
  if (!isAuthenticated) redirect("/login?redirect=/dashboard");
  if (!isMember) redirect("/membership");
  return true;
}

// ── Article / content access ───────────────────────────────────
// Returns true if the user can access a given piece of content
export async function canAccessContent(memberOnly: boolean): Promise<boolean> {
  if (!memberOnly) return true;
  const { isMember } = await getUserAccess();
  return isMember;
}

// ── Middleware helper: is request from a member? ───────────────
export async function checkMembershipFromHeaders(
  stripeCustomerId?: string
): Promise<boolean> {
  if (!stripeCustomerId) return false;
  return hasActiveMembership(stripeCustomerId);
}
