// ═══════════════════════════════════════════════════════════════
// SILENCE THE NOISE™ — Sanity CMS Schemas
// Place these in your /sanity/schemas/ directory
// ═══════════════════════════════════════════════════════════════

import { defineType, defineField } from "sanity";

const PILLAR_OPTIONS = [
  { title: "I — Awareness", value: "awareness" },
  { title: "II — Surrender", value: "surrender" },
  { title: "III — Identity", value: "identity" },
  { title: "IV — Discipline", value: "discipline" },
  { title: "V — Renewal Under Pressure", value: "renewal" },
  { title: "VI — Compassion", value: "compassion" },
  { title: "VII — Integration", value: "integration" },
];

const CATEGORY_OPTIONS = [
  { title: "🌀 Anxiety", value: "anxiety" },
  { title: "🌧 Depression", value: "depression" },
  { title: "🧩 PTSD & Trauma", value: "ptsd" },
  { title: "✝ Faith & Spiritual Renewal", value: "faith" },
  { title: "🌿 Body, Nutrition & Healing", value: "body" },
  { title: "🧭 Purpose", value: "purpose" },
];

// ── Article ────────────────────────────────────────────────────
export const articleSchema = defineType({
  name: "article",
  title: "Article",
  type: "document",
  icon: () => "📄",
  groups: [
    { name: "content", title: "Content", default: true },
    { name: "framework", title: "Framework" },
    { name: "seo", title: "SEO" },
  ],
  fields: [
    defineField({ name: "title", title: "Title", type: "string", group: "content", validation: (R) => R.required() }),
    defineField({ name: "slug", title: "Slug", type: "slug", group: "content", options: { source: "title" }, validation: (R) => R.required() }),
    defineField({ name: "excerpt", title: "Excerpt", type: "text", rows: 3, group: "content", validation: (R) => R.required().max(280) }),
    defineField({ name: "coverImage", title: "Cover Image", type: "image", group: "content", options: { hotspot: true }, fields: [{ name: "alt", type: "string", title: "Alt text" }] }),
    defineField({ name: "body", title: "Body", type: "array", group: "content", of: [
      { type: "block", styles: [{ title: "Normal", value: "normal" }, { title: "H2", value: "h2" }, { title: "H3", value: "h3" }, { title: "Quote", value: "blockquote" }] },
      { type: "image", options: { hotspot: true } },
    ]}),
    defineField({ name: "author", title: "Author", type: "reference", to: [{ type: "author" }], group: "content" }),
    defineField({ name: "publishedAt", title: "Published At", type: "datetime", group: "content" }),
    defineField({ name: "readingTime", title: "Reading Time (minutes)", type: "number", group: "content", initialValue: 5 }),
    // Framework
    defineField({ name: "category", title: "Topic Category", type: "string", group: "framework", options: { list: CATEGORY_OPTIONS }, validation: (R) => R.required() }),
    defineField({ name: "pillars", title: "Framework Pillars", type: "array", group: "framework", of: [{ type: "string" }], options: { list: PILLAR_OPTIONS } }),
    defineField({ name: "tags", title: "Tags", type: "array", group: "framework", of: [{ type: "string" }], options: { layout: "tags" } }),
    defineField({ name: "featured", title: "Featured", type: "boolean", group: "framework", initialValue: false }),
    defineField({ name: "memberOnly", title: "Member Only", type: "boolean", group: "framework", initialValue: false, description: "Toggle on to gate this article behind membership" }),
    // SEO
    defineField({ name: "seo", title: "SEO", type: "seoFields", group: "seo" }),
  ],
  preview: {
    select: { title: "title", subtitle: "category", media: "coverImage", memberOnly: "memberOnly" },
    prepare: ({ title, subtitle, media, memberOnly }) => ({
      title: `${memberOnly ? "🔒 " : ""}${title}`,
      subtitle: CATEGORY_OPTIONS.find((c) => c.value === subtitle)?.title ?? subtitle,
      media,
    }),
  },
  orderings: [{ title: "Published Date", name: "publishedAtDesc", by: [{ field: "publishedAt", direction: "desc" }] }],
});

// ── Devotional ─────────────────────────────────────────────────
export const devotionalSchema = defineType({
  name: "devotional",
  title: "Devotional",
  type: "document",
  icon: () => "✝",
  fields: [
    defineField({ name: "title", title: "Title", type: "string", validation: (R) => R.required() }),
    defineField({ name: "slug", title: "Slug", type: "slug", options: { source: "title" }, validation: (R) => R.required() }),
    defineField({ name: "scripture", title: "Scripture Text", type: "text", rows: 4, validation: (R) => R.required() }),
    defineField({ name: "scriptureReference", title: "Scripture Reference", type: "string", placeholder: "e.g. Philippians 4:6–7", validation: (R) => R.required() }),
    defineField({ name: "reflection", title: "Reflection", type: "array", of: [{ type: "block" }] }),
    defineField({ name: "prayer", title: "Prayer", type: "text", rows: 5 }),
    defineField({ name: "coverImage", title: "Cover Image", type: "image", options: { hotspot: true } }),
    defineField({ name: "publishedAt", title: "Published At", type: "datetime" }),
    defineField({ name: "category", title: "Topic Category", type: "string", options: { list: CATEGORY_OPTIONS } }),
    defineField({ name: "pillars", title: "Framework Pillars", type: "array", of: [{ type: "string" }], options: { list: PILLAR_OPTIONS } }),
    defineField({ name: "theme", title: "Theme", type: "string", options: { list: [
      { title: "Scripture", value: "scripture" }, { title: "Healing", value: "healing" },
      { title: "Justice", value: "justice" }, { title: "Identity", value: "identity" },
      { title: "Prayer", value: "prayer" }, { title: "Gratitude", value: "gratitude" },
      { title: "Purpose", value: "purpose" },
    ]}},
    defineField({ name: "memberOnly", title: "Member Only", type: "boolean", initialValue: false }),
    defineField({ name: "seo", title: "SEO", type: "seoFields" }),
  ],
  preview: {
    select: { title: "title", subtitle: "scriptureReference", media: "coverImage" },
    prepare: ({ title, subtitle, media }) => ({ title, subtitle, media }),
  },
});

// ── Podcast Episode ────────────────────────────────────────────
export const podcastSchema = defineType({
  name: "podcast",
  title: "Podcast Episode",
  type: "document",
  icon: () => "🎙",
  fields: [
    defineField({ name: "title", title: "Title", type: "string", validation: (R) => R.required() }),
    defineField({ name: "slug", title: "Slug", type: "slug", options: { source: "title" } }),
    defineField({ name: "episodeNumber", title: "Episode Number", type: "number", validation: (R) => R.required() }),
    defineField({ name: "description", title: "Description", type: "text", rows: 3 }),
    defineField({ name: "audioUrl", title: "Audio URL", type: "url" }),
    defineField({ name: "duration", title: "Duration (seconds)", type: "number" }),
    defineField({ name: "transcript", title: "Transcript", type: "array", of: [{ type: "block" }] }),
    defineField({ name: "coverImage", title: "Cover Image", type: "image", options: { hotspot: true } }),
    defineField({ name: "publishedAt", title: "Published At", type: "datetime" }),
    defineField({ name: "category", title: "Topic Category", type: "string", options: { list: CATEGORY_OPTIONS } }),
    defineField({ name: "pillars", title: "Framework Pillars", type: "array", of: [{ type: "string" }], options: { list: PILLAR_OPTIONS } }),
    defineField({ name: "memberOnly", title: "Member Only", type: "boolean", initialValue: false }),
  ],
});

// ── Video Series ───────────────────────────────────────────────
export const videoSchema = defineType({
  name: "videoSeries",
  title: "Video Series",
  type: "document",
  icon: () => "🎬",
  fields: [
    defineField({ name: "title", title: "Title", type: "string", validation: (R) => R.required() }),
    defineField({ name: "slug", title: "Slug", type: "slug", options: { source: "title" } }),
    defineField({ name: "seriesNumber", title: "Series Number", type: "number" }),
    defineField({ name: "description", title: "Description", type: "text", rows: 3 }),
    defineField({ name: "videoUrl", title: "Video URL (YouTube/Vimeo)", type: "url" }),
    defineField({ name: "duration", title: "Duration (seconds)", type: "number" }),
    defineField({ name: "thumbnailUrl", title: "Thumbnail", type: "image", options: { hotspot: true } }),
    defineField({ name: "publishedAt", title: "Published At", type: "datetime" }),
    defineField({ name: "category", title: "Topic Category", type: "string", options: { list: CATEGORY_OPTIONS } }),
    defineField({ name: "pillars", title: "Framework Pillars", type: "array", of: [{ type: "string" }], options: { list: PILLAR_OPTIONS } }),
    defineField({ name: "memberOnly", title: "Member Only", type: "boolean", initialValue: false }),
  ],
});

// ── Author ─────────────────────────────────────────────────────
export const authorSchema = defineType({
  name: "author",
  title: "Author",
  type: "document",
  fields: [
    defineField({ name: "name", title: "Full Name", type: "string" }),
    defineField({ name: "credentials", title: "Credentials", type: "string", placeholder: "e.g. MD, FACC" }),
    defineField({ name: "bio", title: "Bio", type: "text", rows: 5 }),
    defineField({ name: "image", title: "Photo", type: "image", options: { hotspot: true } }),
  ],
});

// ── Resource ───────────────────────────────────────────────────
export const resourceSchema = defineType({
  name: "resource",
  title: "Resource",
  type: "document",
  icon: () => "📚",
  fields: [
    defineField({ name: "title", title: "Title", type: "string" }),
    defineField({ name: "slug", title: "Slug", type: "slug", options: { source: "title" } }),
    defineField({ name: "description", title: "Description", type: "text", rows: 3 }),
    defineField({ name: "resourceType", title: "Type", type: "string", options: { list: [
      { title: "PDF", value: "pdf" }, { title: "Guide", value: "guide" },
      { title: "Worksheet", value: "worksheet" }, { title: "Audio", value: "audio" },
      { title: "Video", value: "video" }, { title: "Link", value: "link" },
    ]}},
    defineField({ name: "fileUrl", title: "File URL", type: "url" }),
    defineField({ name: "externalUrl", title: "External URL", type: "url" }),
    defineField({ name: "coverImage", title: "Cover Image", type: "image", options: { hotspot: true } }),
    defineField({ name: "category", title: "Topic Category", type: "string", options: { list: CATEGORY_OPTIONS } }),
    defineField({ name: "pillars", title: "Framework Pillars", type: "array", of: [{ type: "string" }], options: { list: PILLAR_OPTIONS } }),
    defineField({ name: "memberOnly", title: "Member Only", type: "boolean", initialValue: false }),
    defineField({ name: "comingSoon", title: "Coming Soon", type: "boolean", initialValue: false }),
    defineField({ name: "publishedAt", title: "Published At", type: "datetime" }),
  ],
});

// ── SEO object type (shared) ───────────────────────────────────
export const seoFieldsSchema = defineType({
  name: "seoFields",
  title: "SEO Fields",
  type: "object",
  fields: [
    defineField({ name: "metaTitle", title: "Meta Title", type: "string", validation: (R) => R.max(60) }),
    defineField({ name: "metaDescription", title: "Meta Description", type: "text", rows: 2, validation: (R) => R.max(160) }),
    defineField({ name: "ogImage", title: "OG Image", type: "image" }),
    defineField({ name: "noIndex", title: "No Index", type: "boolean", initialValue: false }),
  ],
});

// ── Export all schemas ─────────────────────────────────────────
export const schemaTypes = [
  articleSchema,
  devotionalSchema,
  podcastSchema,
  videoSchema,
  authorSchema,
  resourceSchema,
  seoFieldsSchema,
];
