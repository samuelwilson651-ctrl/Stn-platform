#!/usr/bin/env tsx
/**
 * Silence the Noise™ — Stripe Product Setup Script
 * Run: npm run stripe:setup
 *
 * Creates all products and prices in Stripe and prints the
 * price IDs to add to your .env.local file.
 */

import Stripe from "stripe";

const stripe = new Stripe(process.env.STRIPE_SECRET_KEY!, { apiVersion: "2024-04-10" });

async function setup() {
  console.log("🔧 Setting up Stripe products for Silence the Noise™...\n");
  const results: Record<string, string> = {};

  // ── Community Membership (Monthly) ────────────────────────
  const membershipProduct = await stripe.products.create({
    name: "Silence the Noise™ Community Membership",
    description: "Full access to the STN™ member library — articles, devotionals, podcast, videos, resources, and community.",
    metadata: { type: "membership" },
  });
  const monthlyPrice = await stripe.prices.create({
    product: membershipProduct.id,
    currency: "usd",
    unit_amount: 1700,
    recurring: { interval: "month" },
    nickname: "Monthly Membership",
  });
  results["STRIPE_PRICE_MEMBERSHIP_MONTHLY"] = monthlyPrice.id;
  console.log(`✓ Monthly Membership: ${monthlyPrice.id} ($17/mo)`);

  // ── Community Membership (Annual) ─────────────────────────
  const annualPrice = await stripe.prices.create({
    product: membershipProduct.id,
    currency: "usd",
    unit_amount: 13200,
    recurring: { interval: "year" },
    nickname: "Annual Membership",
  });
  results["STRIPE_PRICE_MEMBERSHIP_ANNUAL"] = annualPrice.id;
  console.log(`✓ Annual Membership: ${annualPrice.id} ($132/yr)`);

  // ── STN Course ─────────────────────────────────────────────
  const courseProduct = await stripe.products.create({
    name: "Silence the Noise™ Course",
    description: "7-module structured journey through the complete Silence the Noise™ framework.",
    metadata: { type: "course" },
  });
  const coursePrice = await stripe.prices.create({
    product: courseProduct.id,
    currency: "usd",
    unit_amount: 29700,
    nickname: "STN Course",
  });
  results["STRIPE_PRICE_COURSE_STN"] = coursePrice.id;
  console.log(`✓ STN Course: ${coursePrice.id} ($297)`);

  // ── Coaching Session ───────────────────────────────────────
  const coachingProduct = await stripe.products.create({
    name: "Silence the Noise™ Coaching Session",
    description: "One 60-minute session with a certified Silence the Noise™ coach.",
    metadata: { type: "coaching" },
  });
  const coachingPrice = await stripe.prices.create({
    product: coachingProduct.id,
    currency: "usd",
    unit_amount: 19700,
    nickname: "Coaching Session",
  });
  results["STRIPE_PRICE_COACHING_SESSION"] = coachingPrice.id;
  console.log(`✓ Coaching Session: ${coachingPrice.id} ($197)`);

  // ── Physician Consultation ─────────────────────────────────
  const consultProduct = await stripe.products.create({
    name: "Physician Consultation — Dr. Samuel E. Wilson, MD",
    description: "One-on-one consultation with Dr. Wilson.",
    metadata: { type: "consultation" },
  });
  const consultPrice = await stripe.prices.create({
    product: consultProduct.id,
    currency: "usd",
    unit_amount: 49700,
    nickname: "Physician Consultation",
  });
  results["STRIPE_PRICE_CONSULTATION"] = consultPrice.id;
  console.log(`✓ Physician Consultation: ${consultPrice.id} ($497)`);

  // ── Print env vars ─────────────────────────────────────────
  console.log("\n✅ Done! Add these to your .env.local:\n");
  Object.entries(results).forEach(([key, value]) => {
    console.log(`${key}=${value}`);
  });

  console.log("\n📋 Also register your Stripe webhook:");
  console.log("   stripe listen --forward-to localhost:3000/api/webhooks/stripe");
  console.log("   or: https://dashboard.stripe.com/webhooks");
  console.log("\nEvents to subscribe:");
  [
    "checkout.session.completed",
    "customer.subscription.created",
    "customer.subscription.updated",
    "customer.subscription.deleted",
    "invoice.payment_failed",
  ].forEach((e) => console.log(`   ✓ ${e}`));
}

setup().catch(console.error);
